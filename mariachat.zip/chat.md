# Exportación de chat de WhatsApp: +58 414-5812572
Fecha de exportación: 7 de noviembre de 2026 a las 14:34

---

## 2 de noviembre de 2026

[21:20] __Los mensajes y las llamadas están cifrados de extremo a extremo. Nadie fuera de este chat, ni siquiera WhatsApp, puede leerlos ni escucharlos. Toca para obtener más información.__

[21:25] **Tú:** Holaa maría como estas buenas noches, supongo que tu amiga saray te comento que me daría tu número, que tal tu día de hoy?

[21:40] **Maria. Valencia:** holahola

[21:40] **Maria. Valencia:** si me dijo, me pareció como raro pero

[21:41] **Maria. Valencia:** y normalin, llegue hace rato del gym

[21:41] **Maria. Valencia:** ya voy lista para dormir mas bn

[21:41] **Maria. Valencia:** si la luz no se hubiera ido

[21:41] **Maria. Valencia:** [Sticker]

[21:43] **Maria. Valencia:** soy de valencia xd creo que es bueno saberlo, yo solo era turista en ccs

[21:43] **Tú:**
> _Maria. Valencia: y normalin, llegue hace rato del gym_
ohh mira tu yo llegue como a las 6 por alli mas o menos

[21:43] **Tú:**
> _Maria. Valencia: si la luz no se hubiera ido_
ay😅😅

[21:43] **Tú:** te imagino asi

[21:43] **Tú:** [Sticker]

[21:44] **Tú:**
> _Maria. Valencia: soy de valencia xd creo que es bueno saberlo, yo solo era turista en ccs_
mira ya tenemos algo en común yo tambien era turista en ccs soy de la guaira fue para alla por mis amigos primera vez que salgo asi la verdad, ni pensaba disfrazarme ni nada

[21:45] **Tú:**
> _Maria. Valencia: si me dijo, me pareció como raro pero_
es que nunca pense ver a nadie de mujer con ese cosplay y pues tuve la ilusion de tirarme la foto

[22:05] **Maria. Valencia:**
> _Tú: Sticker_
total

[22:06] **Maria. Valencia:**
> _Tú: mira ya tenemos algo en común yo tambien era turista en ccs soy de la guaira fue para alla por mis amigos primera vez que salgo asi la verdad, ni pensaba disfrazarme ni nada_
perdidos en chacayork

[22:06] **Maria. Valencia:** yo si lo tenia planeado

[22:06] **Maria. Valencia:** pero me hubiese ido de Jason

[22:06] **Maria. Valencia:** [Sticker]

[22:07] **Tú:**
> _Maria. Valencia: perdidos en chacayork_
no estábamos en las mercedes?😅😅

[22:07] **Maria. Valencia:**
> _Tú: Imagen_
ay yo tambien voy a aprovechar el traje para llevarlo al gym

[22:07] **Maria. Valencia:**
> _Tú: no estábamos en las mercedes?😅😅_
berro

[22:07] **Maria. Valencia:** tengo entendido que por esa zona es la que le dicen asi

[22:07] **Maria. Valencia:** asi me dijeron el domingo

[22:08] **Maria. Valencia:** porque aca en valencia hay una zona que tmb se parece mucho

[22:08] **Tú:**
> _Maria. Valencia: yo si lo tenia planeado_
[Mensaje de voz]

[22:08] **Tú:**
> _Maria. Valencia: porque aca en valencia hay una zona que tmb se parece mucho_
ohh yaya

[22:09] **Maria. Valencia:**
> _Tú: Imagen_
fua

[22:09] **Tú:** yo no he ido mucha valencia pero si he pasado, cerca de allí cuando voy a puerto cabello porque tengo familia de hecho pronto debería ir para allá a visitar

[22:10] **Tú:**
> _Maria. Valencia: pero me hubiese ido de Jason_
uyy buena idea pero ese la verdad te quedo muy lindo y mas tu que eres muy linda supiste lucir el disfraz 🫶🏽

[22:10] **Maria. Valencia:**
> _Tú: Mensaje de voz_
yo queria irme originalmente del gato del país de las maravillas

[22:10] **Maria. Valencia:** pero la versión azul sabes?

[22:11] **Tú:**
> _Maria. Valencia: pero la versión azul sabes?_
sisi

[22:11] **Tú:** demasiado original nunca he visto a nadie con ese la verdad

[22:11] **Maria. Valencia:** pero no le hallé uso después, esa puro gastar la plata

[22:11] **Tú:**
> _Maria. Valencia: pero no le hallé uso después, esa puro gastar la plata_
claro claro entiendo

[22:12] **Tú:** yo por eso me anime para darle el uso luego a las cosas

[22:12] **Tú:** y alli guarde todo los palitos y los demas, queria hacer que los palitos encendieran como linternas pero por falta de dinero y tiempo no se me dio

[22:12] **Tú:** y nada que te llega la luz?

[22:14] **Maria. Valencia:**
> _Tú: demasiado original nunca he visto a nadie con ese la verdad_
[Sticker]

[22:14] **Maria. Valencia:** ea si vi varios tipos que iban igual jaja

[22:15] **Maria. Valencia:** pero tambien vi varias raven

[22:15] **Maria. Valencia:** le tuve envidia a los que fueron de donde estan las rubias, los viste?

[22:16] **Maria. Valencia:**
> _Tú: y alli guarde todo los palitos y los demas, queria hacer que los palitos encendieran como linternas pero por falta de dinero y tiempo no se me dio_
yo iba a comprar espadas led y las iba llenar de cinta aislante

[22:16] **Maria. Valencia:** pero no me dio chance

[22:16] **Maria. Valencia:**
> _Tú: y nada que te llega la luz?_
nai

[22:20] **Tú:**
> _Maria. Valencia: ea si vi varios tipos que iban igual jaja_
enserió?

[22:20] **Tú:**
> _Maria. Valencia: pero tambien vi varias raven_
sii yo vi como 3 y 2 starfire

[22:21] **Tú:**
> _Maria. Valencia: le tuve envidia a los que fueron de donde estan las rubias, los viste?_
siii iban grabando o stremeando por alli, mi amigo esta viendo si los encuentra porque les dio hasta un beso en esa jodedera

[22:21] **Tú:**
> _Maria. Valencia: nai_
ay ñomiooo

---

## 3 de noviembre de 2026

[10:45] **Maria. Valencia:**
> _Tú: enserió?_
jsks si

[10:45] **Maria. Valencia:** buenass

[10:45] **Maria. Valencia:** me habia dormido y pase de largo

[10:46] **Maria. Valencia:** hoy falté, no tenia ganitas de ir a trabajar

[10:46] **Maria. Valencia:**
> _Tú: siii iban grabando o stremeando por alli, mi amigo esta viendo si los encuentra porque les dio hasta un beso en esa jodedera_
fua que nervio jaja

[10:47] **Maria. Valencia:** y tu qué tienes hoy?

[10:47] **Tú:**
> _Maria. Valencia: y tu qué tienes hoy?_
sueñoo jsjsjsj

[10:48] **Tú:**
> _Maria. Valencia: buenass_
[Mensaje de voz]

[10:48] **Tú:**
> _Maria. Valencia: hoy falté, no tenia ganitas de ir a trabajar_
ay y de que trabajas?

[10:48] **Tú:**
> _Maria. Valencia: me habia dormido y pase de largo_
si imagine como me dijiste que estabas cansada y eso

[10:49] **Tú:** ya vengo ire a lavarme la cara y cepillarme

[10:50] **Tú:**
> _Maria. Valencia: y tu qué tienes hoy?_
[Mensaje de voz]

[11:25] **Tú:** Hola, maría creo que no sabia que tenias novia y me escribió alguien en mis photo dumps que subi ese día ya elimine el video para no causar inconvenientes y disculpa si hice algo que incomodo/molesto

[11:26] **Maria. Valencia:**
> _Tú: ay y de que trabajas?_
yo trabajo en un comedor

[11:27] **Maria. Valencia:**
> _Tú: Hola, maría creo que no sabia que tenias novia y me escribió alguien en mis photo dumps que subi ese día ya elimine el video para no causar inconvenientes y disculpa si hice algo que incomodo/molesto_
jaja es qje a mi me lo pasaron y se lo mostré a una amiga

[11:27] **Maria. Valencia:** esa fue ella marcando territorio

[11:28] **Tú:**
> _Maria. Valencia: esa fue ella marcando territorio_
[Mensaje de voz]

[11:28] **Maria. Valencia:**
> _Tú: Mensaje de voz_
ay pero que rela

[11:28] **Maria. Valencia:** q envidia

[11:29] **Maria. Valencia:** a mi tambien me toca pierna

[11:29] **Maria. Valencia:** pero yo voy en la noche para hacer el paripé de que fui a la jornada

[11:29] **Maria. Valencia:**
> _Tú: Mensaje de voz_
JAJAJAJ

[11:29] **Tú:**
> _Maria. Valencia: jaja es qje a mi me lo pasaron y se lo mostré a una amiga_
no hay problema que lo resuba entonces? para saber si te incomoda o algo, no te pude preguntar ese día porque saray no me respondio

[11:30] **Maria. Valencia:** bno pos si

[11:30] **Tú:**
> _Maria. Valencia: pero yo voy en la noche para hacer el paripé de que fui a la jornada_
claro entiendo, entiendo

[11:30] **Maria. Valencia:**
> _Tú: no hay problema que lo resuba entonces? para saber si te incomoda o algo, no te pude preguntar ese día porque saray no me respondio_
[Sticker]

[11:31] **Maria. Valencia:** yo salí bn humilde

[11:31] **Maria. Valencia:** se me nota que salí de la lata de sardinas ksjs

[11:31] **Maria. Valencia:** quedaría mejor de recuerdo

[11:31] **Tú:**
> _Maria. Valencia: yo salí bn humilde_
por eso pregunte si no te gusta ya que tengo tu número y puedo comunicarme, no lo subo contigo

[11:32] **Maria. Valencia:**
> _Tú: por eso pregunte si no te gusta ya que tengo tu número y puedo comunicarme, no lo subo contigo_
[Sticker]

[11:32] **Tú:**
> _Maria. Valencia: quedaría mejor de recuerdo_
[Mensaje de voz]

[11:32] **Maria. Valencia:** pero si, enfim, por la pasada de mi amiga

[11:32] **Maria. Valencia:** q pena

[11:32] **Tú:**
> _Maria. Valencia: pero si, enfim, por la pasada de mi amiga_
es que me paso algo similar te lo juro

[11:32] **Tú:** en el gym

[11:32] **Tú:** y quede demasiado traumado

[11:32] **Tú:** [Sticker]

[11:34] **Tú:** [Mensaje de voz]

[11:34] **Tú:** disculpa el audio largo

[11:34] **Tú:** [Sticker]

[11:34] **Maria. Valencia:**
> _Tú: Mensaje de voz_
nai tranquilo, tampoco te iba a reportar

[11:34] **Maria. Valencia:** JAJAJA

[11:34] **Maria. Valencia:** fua

[11:34] **Maria. Valencia:**
> _Tú: y quede demasiado traumado_
pero que fue

[11:34] **Tú:**
> _Tú: Mensaje de voz_
alli esta el mini story time

[11:35] **Maria. Valencia:** con una chama de novia con un cicpc oque

[11:35] **Tú:**
> _Maria. Valencia: con una chama de novia con un cicpc oque_
ah bueno tambien tengo una historia parecida que termine en un modulo policial por culpa de un amigo y su cuadre

[11:36] **Maria. Valencia:**
> _Tú: Mensaje de voz_
que loco

[11:36] **Maria. Valencia:** tmb un poco rara

[11:36] **Tú:**
> _Maria. Valencia: tmb un poco rara_
seh pero como que se salieron del gym ya, pero el tiempo que estuvieron despues de ese día si fue incomodo

[11:38] **Maria. Valencia:**
> _Tú: ah bueno tambien tengo una historia parecida que termine en un modulo policial por culpa de un amigo y su cuadre_
berro por lo menos anécdotas no faltan

[11:39] **Maria. Valencia:** jsksj yo no tengo amigos asi desastrosos

[11:39] **Maria. Valencia:** mas bien salí en halloween porque mi prima quiso llevarme

[11:39] **Tú:**
> _Maria. Valencia: berro por lo menos anécdotas no faltan_
no conmigo es difícil aburrirse jsjsjs

[11:39] **Tú:**
> _Maria. Valencia: mas bien salí en halloween porque mi prima quiso llevarme_
saray es tu prima?

[11:40] **Maria. Valencia:**
> _Tú: seh pero como que se salieron del gym ya, pero el tiempo que estuvieron despues de ese día si fue incomodo_
mi mayor miedo wn

[11:40] **Maria. Valencia:** yo por eso no ando pendiente de nada en el gym

[11:40] **Maria. Valencia:** a lo mucho veo una camisa chistosa

[11:40] **Maria. Valencia:**
> _Tú: saray es tu prima?_
seee

[11:41] **Tú:** [Mensaje de voz]

[11:41] **Tú:**
> _Tú: Mensaje de voz_
es como cuando te haces novi@ de alguien del trabajo y no se da

[11:41] **Maria. Valencia:** mas bien pensé que la foto era una excusa para ella

[11:41] **Maria. Valencia:** y cuando me escribió me quede ??

[11:42] **Tú:**
> _Maria. Valencia: mas bien pensé que la foto era una excusa para ella_
no valee, es que eres muy linda y me gusto como ibas con el cosplay y me acorde lo que me dice mi mama

[11:42] **Tú:** pena son 4 letras

[11:42] **Maria. Valencia:**
> _Tú: Mensaje de voz_
tu amigo el mejor promotor de cizaña

[11:42] **Tú:**
> _Maria. Valencia: tu amigo el mejor promotor de cizaña_
literal

[11:42] **Tú:** siempre que salgo con el mi mood es asi

[11:42] **Tú:** [Sticker]

[11:42] **Tú:** [Sticker]

[11:42] **Maria. Valencia:**
> _Tú: es como cuando te haces novi@ de alguien del trabajo y no se da_
bno eso es lo mas común del mundo

[11:43] **Maria. Valencia:** donde yo trabajo parece un reality por eso jakss

[11:43] **Maria. Valencia:** no los culpo pero

[11:44] **Maria. Valencia:** si pasan todos los dias en un mismo lugar

[11:44] **Tú:**
> _Maria. Valencia: donde yo trabajo parece un reality por eso jakss_
dios mio jksjsjsjsj

[11:44] **Maria. Valencia:** te pega como estocolmo tmb

[11:44] **Tú:**
> _Maria. Valencia: te pega como estocolmo tmb_
vrg, entiendo

[11:45] **Tú:** y cuantos años tienes maria?

[11:52] **Maria. Valencia:** tengo 23

[11:52] **Maria. Valencia:** :b

[11:53] **Maria. Valencia:** y tu cuánto?

[11:58] **Tú:** 19 casi 20

[11:58] **Tú:**
> _Maria. Valencia: tengo 23_
ya cumplidos o cumples 24 este año?

[12:02] **Maria. Valencia:**
> _Tú: ya cumplidos o cumples 24 este año?_
me faltan los 24 en diciembre

[12:02] **Maria. Valencia:** de paso

[12:03] **Maria. Valencia:** [Sticker]

[12:03] **Tú:**
> _Maria. Valencia: de paso_
y porque de paso, ya no quieres seguir creciendo?

[12:03] **Tú:**
> _Maria. Valencia: me faltan los 24 en diciembre_
que buenoo, almenos de mi parte tendrás un regalo seguro🫶🏽

[12:03] **Tú:** [Sticker]

[12:20] **Maria. Valencia:**
> _Tú: y porque de paso, ya no quieres seguir creciendo?_
jaja

[12:20] **Maria. Valencia:** la tipica de que el numero sube pero yo no

[12:20] **Maria. Valencia:** [Sticker]

[12:22] **Maria. Valencia:** y me imagino que en tu trabajo basta con cumplir las horas?

[12:22] **Maria. Valencia:** o solo tienes los fines libres?

[12:22] **Tú:**
> _Maria. Valencia: y me imagino que en tu trabajo basta con cumplir las horas?_
no

[12:22] **Tú:** yo soy mi propio jefe

[12:22] **Maria. Valencia:** ah caray

[12:22] **Maria. Valencia:** otra voz tons

[12:23] **Tú:** [Mensaje de voz]

[12:23] **Tú:**
> _Maria. Valencia: la tipica de que el numero sube pero yo no_
ay😅

[12:24] **Tú:** [Mensaje de voz]

[12:25] **Tú:** tengo mi portafolio digital en Google y mi aplicación tambien asi que cuando la buscas hasta la IA de google te da un mini resumen de que es.

En mi portafolio, alli se ve a la gente que le he hecho trabajos y hasta mi propia aplicación creada por mi que ya llevo 3 clientes si en algun momento gustas y estas libre te paso el link para que le heches un ojo

[18:25] **Maria. Valencia:**
> _Tú: Mensaje de voz_
ah vale como por proyecto

[18:26] **Maria. Valencia:**
> _Tú: Mensaje de voz_
wa de medicina a informática

[18:27] **Maria. Valencia:**
> _Tú: tengo mi portafolio digital en Google y mi aplicación tambien asi que cuando la buscas hasta la IA de google te da un mini resumen de que es.

En mi portafolio, alli se ve a la gente que le he hecho trabajos y hasta mi propia aplicación creada por mi que ya llevo 3 clientes si en algun momento gustas y estas libre te paso el link para que le heches un ojo_
tranqui que igual yo un potencial cliente no soy jsksjs

[18:28] **Maria. Valencia:** tmb escojo creer

[18:28] **Maria. Valencia:** no he tenido señal en todo el dia

[18:28] **Tú:**
> _Maria. Valencia: tranqui que igual yo un potencial cliente no soy jsksjs_
tranquilaaa para quitarte dinero para eso te doy, aveces uno debe llegar a la vida de la gente a sumar no restar

[18:29] **Tú:**
> _Maria. Valencia: no he tenido señal en todo el dia_
coye imagino tranquila yo recién llegue del gym y me hice un batido para y me hago la cena mas tarde

[18:29] **Tú:**
> _Maria. Valencia: wa de medicina a informática_
sii algo loco la verdad

[18:30] **Tú:**
> _Maria. Valencia: no he tenido señal en todo el dia_
y lograste ir al gym y eso?

[18:33] **Maria. Valencia:**
> _Tú: tranquilaaa para quitarte dinero para eso te doy, aveces uno debe llegar a la vida de la gente a sumar no restar_
jaja ya me gustaria ver el intento

[18:33] **Maria. Valencia:**
> _Tú: coye imagino tranquila yo recién llegue del gym y me hice un batido para y me hago la cena mas tarde_
ah pero vives solo? o cada quien resuelve su comida?

[18:33] **Maria. Valencia:**
> _Tú: y lograste ir al gym y eso?_
voy a salir en un ratito

[18:33] **Maria. Valencia:** es mas, probablemente cuando te lleguen los mensajes es que estoy con el wifi del gym

[18:34] **Tú:**
> _Maria. Valencia: jaja ya me gustaria ver el intento_
vava, no te preocupues que mentiroso no soy y mucho menos mal hombre, pero eso lo dira mis acciones y no mis palabras

[18:36] **Tú:**
> _Maria. Valencia: ah pero vives solo? o cada quien resuelve su comida?_
[Mensaje de voz]

[18:37] **Tú:**
> _Maria. Valencia: es mas, probablemente cuando te lleguen los mensajes es que estoy con el wifi del gym_
ahh tranquila no te preocupes que te vaya super bien entonces en tu día de pierna mari te deseo lo mejor, y que logres todo tus ejercicios de manera correcta🫶🏽

[18:38] **Tú:**
> _Tú: Mensaje de voz_
entonces, aprendí a hacer mis cosas solo para sumar en la casa y no restar ya que vivo con mi mama, papá y hermano

[20:43] **Maria. Valencia:** ya voy a terminar yava

[20:58] **Tú:**
> _Maria. Valencia: ya voy a terminar yava_
anda esta bien tranquila cuidate de camino a casa, porfa

[21:22] **Maria. Valencia:** ya llegue y me bañé

[21:22] **Maria. Valencia:** [Sticker]

[21:23] **Maria. Valencia:**
> _Tú: Mensaje de voz_
es como raro escucharlo de primera instancia jaja pero son buenos valores

[21:23] **Maria. Valencia:** son pequeñas cosas que se aprecian

[21:23] **Maria. Valencia:**
> _Tú: ahh tranquila no te preocupes que te vaya super bien entonces en tu día de pierna mari te deseo lo mejor, y que logres todo tus ejercicios de manera correcta🫶🏽_
graciass, hoy fue horrible

[21:24] **Maria. Valencia:** estoy muy tembleque todavia 😔

[21:24] **Maria. Valencia:** y como te fue a ti hoy?

[21:24] **Maria. Valencia:**
> _Tú: entonces, aprendí a hacer mis cosas solo para sumar en la casa y no restar ya que vivo con mi mama, papá y hermano_
oh a ver, eres el menor de los dos???

[21:25] **Maria. Valencia:** yo tambien tengo una hermana, solo que se fue del país hace años

[21:25] **Maria. Valencia:** ya parezco hija unica mas bn xdxd

[21:26] **Maria. Valencia:** yo vivo es con mi mamá y mi abuela, porque mi papá siempre ha estado en otro país tambien. siempre hemos sido nosotras

[21:29] **Tú:**
> _Maria. Valencia: ya llegue y me bañé_
que bueno

[21:30] **Tú:**
> _Maria. Valencia: oh a ver, eres el menor de los dos???_
el mayor yo era hijo único y yo pedi a mi hermano porque tenia de todo pero no tenia con quien compartir y como no salía mucho de casa no tenía amigos en ese momento, y dije🤔 y si le pido a santa un hermano y se lo pedi a santa y a al año por ahí me lo trajo

[21:30] **Tú:** yo tengo 19 y el 11 osea le saco 8 años

[21:31] **Maria. Valencia:** waos

[21:31] **Maria. Valencia:** haksjaks que adorable

[21:31] **Maria. Valencia:** a mi me pasa algo igual

[21:31] **Maria. Valencia:** yo si soy la menor

[21:32] **Maria. Valencia:** porque mi mamá le dio miedo dejar a mi hermana sola, pero lo hizo 10 años tarde

[21:32] **Tú:**
> _Maria. Valencia: es como raro escucharlo de primera instancia jaja pero son buenos valores_
perdón si fue raro/incomodo jsjsjs

[21:33] **Tú:**
> _Maria. Valencia: y como te fue a ti hoy?_
bien ya desbloque los 110kg en la Smith haciendo sentadillas y subi un poco el peso en prensa

[21:33] **Maria. Valencia:**
> _Tú: perdón si fue raro/incomodo jsjsjs_
ah nono, cada quien presume sus fortalezas como quiere

[21:33] **Tú:** y mamado y medio

[21:33] **Maria. Valencia:** no esta mal tampoco

[21:33] **Tú:**
> _Maria. Valencia: ah nono, cada quien presume sus fortalezas como quiere_
tranquila, tranquila

[21:33] **Tú:**
> _Maria. Valencia: yo tambien tengo una hermana, solo que se fue del país hace años_
y a que país se fue??

[21:33] **Maria. Valencia:**
> _Tú: bien ya desbloque los 110kg en la Smith haciendo sentadillas y subi un poco el peso en prensa_
[Sticker]

[21:34] **Maria. Valencia:** que pro

[21:34] **Maria. Valencia:** algun dia yo

[21:34] **Tú:**
> _Maria. Valencia: que pro_
shi

[21:34] **Maria. Valencia:** nawara

[21:34] **Maria. Valencia:**
> _Tú: y mamado y medio_
tambien

[21:34] **Maria. Valencia:** JAJAJA

[21:34] **Tú:**
> _Maria. Valencia: algun dia yo_
tranquila mari todo es un proceso lo importante es disfrutar

[21:34] **Maria. Valencia:** menos mal me toca trabajar mañana en la noche

[21:34] **Tú:**
> _Maria. Valencia: menos mal me toca trabajar mañana en la noche_
si no, imagínate jsjsjsj

[21:34] **Tú:**
> _Maria. Valencia: yo vivo es con mi mamá y mi abuela, porque mi papá siempre ha estado en otro país tambien. siempre hemos sido nosotras_
ohh entiendo, entiendo

[21:34] **Maria. Valencia:**
> _Tú: y a que país se fue??_
los dos andan en brasil

[21:34] **Maria. Valencia:** pero viven separados

[21:35] **Tú:** ohh yaya yo tengo es familia pero es en estados unidos

[21:35] **Tú:** mi mama porque nunca se quiso ir y se quedó guerreando por aca

[21:37] **Tú:** y el gym de queda mas o menos cerca de tu casa?

[21:37] **Tú:** el mio queda a 20 minutos en bus por eso voy un poco mas temprano

[21:42] **Maria. Valencia:**
> _Tú: y el gym de queda mas o menos cerca de tu casa?_
sii, solo que ahorita me pedí taxi de regreso

[21:42] **Maria. Valencia:** pero a patica son como 10 min

[21:42] **Tú:**
> _Maria. Valencia: sii, solo que ahorita me pedí taxi de regreso_
ahh esta bien

[21:42] **Maria. Valencia:** y voy dependiendo del horario

[21:42] **Tú:** y tienes algun pasatiempo/hobby que te guste? aparte de ir al gym

[21:43] **Maria. Valencia:** hoy porque me quedé dormida y bue

[21:43] **Tú:**
> _Maria. Valencia: hoy porque me quedé dormida y bue_
pasan que cosas jsjjsjs

[21:43] **Maria. Valencia:**
> _Tú: y tienes algun pasatiempo/hobby que te guste? aparte de ir al gym_
siempre ando leyendo mangas o manhwas, si no ando jugando tmb

[21:44] **Tú:**
> _Maria. Valencia: y voy dependiendo del horario_
entiendo, entiendo yo porque siempre voy de 2 a 5 y asi

[21:44] **Maria. Valencia:** ahorita estoy jugando persona 3 que me tiene la vida triste

[21:44] **Tú:**
> _Maria. Valencia: siempre ando leyendo mangas o manhwas, si no ando jugando tmb_
ves anime??? o solo mangas

[21:44] **Maria. Valencia:** voy en septiembre

[21:44] **Maria. Valencia:**
> _Tú: entiendo, entiendo yo porque siempre voy de 2 a 5 y asi_
vas libre de semestre supongo?

[21:45] **Maria. Valencia:**
> _Tú: ves anime??? o solo mangas_
mira el ultimo anime que me vi fue

[21:45] **Maria. Valencia:** cuando sacaron el spin off de inuyasha

[21:45] **Maria. Valencia:** que flopeó horrible

[21:45] **Tú:**
> _Maria. Valencia: voy en septiembre_
no se mucho de persona pero si mis amigos me han comentado un poco

[21:46] **Maria. Valencia:** jajaja y eso que ahora la autora sacó otro como de trama similar

[21:46] **Tú:**
> _Maria. Valencia: cuando sacaron el spin off de inuyasha_
yo vi ese anime pero cuando estaba muy chiquito

[21:46] **Tú:**
> _Maria. Valencia: jajaja y eso que ahora la autora sacó otro como de trama similar_
imaginate jsjsjsj

[21:46] **Tú:**
> _Maria. Valencia: ahorita estoy jugando persona 3 que me tiene la vida triste_
y lo juegas en el teléfono?

[21:46] **Maria. Valencia:**
> _Tú: yo vi ese anime pero cuando estaba muy chiquito_
ese es infancia, uno de los que tolero en español

[21:47] **Tú:**
> _Maria. Valencia: ese es infancia, uno de los que tolero en español_
si jsjjs

[21:47] **Maria. Valencia:**
> _Tú: no se mucho de persona pero si mis amigos me han comentado un poco_
es fino, tiene hasta anime

[21:47] **Maria. Valencia:** es de combate por turnos, creo que tipo pokemon

[21:48] **Tú:**
> _Maria. Valencia: voy en septiembre_
un amigo que jugo eso me dijo que ese mes era una super ladilla y como lo dices confirmas lo que me han dicho que justamente en septiembre la historia se pone súper pesada y triste

[21:48] **Maria. Valencia:** pero puedes hacer distintas cosas para subir tus stats y las relaciones con otros pjs

[21:48] **Maria. Valencia:**
> _Tú: un amigo que jugo eso me dijo que ese mes era una super ladilla y como lo dices confirmas lo que me han dicho que justamente en septiembre la historia se pone súper pesada y triste_
[Sticker]

[21:48] **Tú:**
> _Maria. Valencia: es de combate por turnos, creo que tipo pokemon_
ohhh yaya asi entiendo un poco mejor😅

[21:48] **Tú:**
> _Maria. Valencia: Sticker_
tu jsjsjsj

[21:48] **Maria. Valencia:**
> _Tú: y lo juegas en el teléfono?_
lo compre en la switch jeje

[21:48] **Tú:**
> _Maria. Valencia: pero puedes hacer distintas cosas para subir tus stats y las relaciones con otros pjs_
coye esta divertido entonces

[21:48] **Tú:**
> _Maria. Valencia: lo compre en la switch jeje_
uyyy swicht 1 o 2?

[21:48] **Maria. Valencia:**
> _Tú: tu jsjsjsj_
bueno es que lit es juego es asi

[21:49] **Maria. Valencia:** es medio emo

[21:49] **Maria. Valencia:**
> _Tú: uyyy swicht 1 o 2?_
la dos

[21:49] **Tú:**
> _Maria. Valencia: la dos_
ay mi ma.

[21:49] **Maria. Valencia:** sii, tengo poquitos juegos

[21:49] **Tú:** yo porque siempre he sido de pc y bueno dure como 1 año y medio ahorrando y logre montar mi setup

[21:49] **Maria. Valencia:** me he controlado porque no he terminado persona

[21:50] **Maria. Valencia:**
> _Tú: yo porque siempre he sido de pc y bueno dure como 1 año y medio ahorrando y logre montar mi setup_
si? se puede ver?

[21:50] **Tú:**
> _Maria. Valencia: si? se puede ver?_
obvio jsjsjsjs

[21:50] **Tú:** dame un momentito te paso foto

[21:50] **Maria. Valencia:** yo la compre porque supe que iban a sacar nuevos juegos y de paso el zelda

[21:50] **Tú:**
> _Maria. Valencia: yo la compre porque supe que iban a sacar nuevos juegos y de paso el zelda_
dios mio amo zelda

[21:51] **Tú:** [Imagen]

[21:51] **Tú:** [Mensaje de unknown]

[21:51] **Tú:**
> _Tú: Imagen_
el case cambia a colores de gusto pero siempre lo rotó entre rojo y azul

[21:51] **Maria. Valencia:**
> _Tú: Imagen_
wa el lol

[21:52] **Tú:**
> _Maria. Valencia: yo la compre porque supe que iban a sacar nuevos juegos y de paso el zelda_
yo jugue el Breath of the Wild

[21:52] **Maria. Valencia:** esta brutall

[21:52] **Tú:** y fue el que me enamoro en conocer zelda

[21:52] **Tú:**
> _Maria. Valencia: wa el lol_
buenooo ese juegito lo conocí porque fue con el que saque dinero

[21:52] **Tú:** me gusta y lo odio

[21:52] **Tú:** mi favorito es fortnite

[21:53] **Maria. Valencia:**
> _Tú: buenooo ese juegito lo conocí porque fue con el que saque dinero_
JAJAJA si, yo conozco una amiga que vendia cuentas

[21:53] **Maria. Valencia:** si se le saca

[21:53] **Tú:** y como tengo pavos infinitos ya que aproveche comprar el salvar al mundo en sus inicios salí ganador

[21:53] **Tú:**
> _Maria. Valencia: JAJAJA si, yo conozco una amiga que vendia cuentas_
yo las subía me pagaba y las subía

[21:53] **Maria. Valencia:** yo si es verdad que nunca le entendí jsks

[21:53] **Maria. Valencia:**
> _Tú: mi favorito es fortnite_
ea no lo he jugado tampoco

[21:53] **Maria. Valencia:** deberia intentar

[21:54] **Maria. Valencia:** [Sticker]

[21:54] **Maria. Valencia:** pero pesa burda

[21:54] **Tú:**
> _Maria. Valencia: deberia intentar_
no estaria mal la verdad es gratis

[21:54] **Tú:**
> _Maria. Valencia: pero pesa burda_
enserió?

[21:54] **Tú:** ahorita le bajaron el pc

[21:54] **Maria. Valencia:**
> _Tú: enserió?_
si pesa como

[21:54] **Tú:** peso*

[21:54] **Maria. Valencia:** 50gb

[21:54] **Tú:** en pc me peso como 40 y algo

[21:55] **Tú:** [Mensaje de voz]

[21:57] **Tú:** [Mensaje de voz]

[21:58] **Tú:**
> _Maria. Valencia: deberia intentar_
lo bueno es que te puedo patrocinar las skins que quieras gracias a los pavos infinitos

[21:58] **Tú:**
> _Maria. Valencia: esta brutall_
shi, empecé con una canaima y cantv y alli fue acomodando mi rinconsito

[22:01] **Maria. Valencia:**
> _Tú: Mensaje de voz_
demasiao

[22:01] **Maria. Valencia:** yo de esos no le se a ninguno

[22:01] **Maria. Valencia:** porque como juego de esos pagos JAJAJAJ

[22:02] **Maria. Valencia:** a jurito porque sino vuelvo la switch en un ladrillo

[22:02] **Maria. Valencia:** pero soy malisima la verda

[22:02] **Maria. Valencia:** soy buena siendo guia, apoyo moral

[22:02] **Maria. Valencia:** me gusta mas ver gameplays jsksj

[22:03] **Tú:**
> _Maria. Valencia: soy buena siendo guia, apoyo moral_
no esta mal al final del día los juegos son para pasar un rato agradable y conocer no?

[22:03] **Tú:**
> _Maria. Valencia: me gusta mas ver gameplays jsksj_
jsjsjsjs ya te imagino ya

[22:03] **Maria. Valencia:**
> _Tú: Mensaje de voz_
por lo menos la switch es portable

[22:03] **Maria. Valencia:** me parecee

[22:03] **Maria. Valencia:** yo tengo turnos rotativos, y estoy pasando por los fines de semana

[22:03] **Tú:**
> _Maria. Valencia: por lo menos la switch es portable_
es una super ventaja la verdad yo si no estoy en mi casa ando asi

[22:03] **Tú:** [Sticker]

[22:03] **Maria. Valencia:** mas bn me dices cuando tienes chance

[22:03] **Maria. Valencia:**
> _Tú: lo bueno es que te puedo patrocinar las skins que quieras gracias a los pavos infinitos_
[Sticker]

[22:04] **Tú:**
> _Maria. Valencia: mas bn me dices cuando tienes chance_
yo casi siempre estoy libre asi ntp

[22:04] **Tú:** tu dime y yo resuelvo🫶🏽

[22:04] **Maria. Valencia:**
> _Tú: shi, empecé con una canaima y cantv y alli fue acomodando mi rinconsito_
q envidia, yo es que nunca tuve una

[22:04] **Maria. Valencia:** sigo teniendo internet maluco pero

[22:05] **Maria. Valencia:**
> _Tú: tu dime y yo resuelvo🫶🏽_
vale bno, esta semana tengo libre de sabado al lunes

[22:05] **Maria. Valencia:** no digo viernes porque vengo amanecida

[22:06] **Tú:**
> _Maria. Valencia: no digo viernes porque vengo amanecida_
no vale no te preocupes primero tu salud y jugamos mas tranquilos el sábado

[22:06] **Tú:**
> _Maria. Valencia: sigo teniendo internet maluco pero_
ayy jsjsj

[22:06] **Tú:** y tienes alguna comida favorita mari?

[22:07] **Maria. Valencia:**
> _Tú: no vale no te preocupes primero tu salud y jugamos mas tranquilos el sábado_
tons en donde? caracas igual?

[22:07] **Maria. Valencia:** yo no me se mover nadita por ahi, eso si

[22:07] **Tú:** yava

[22:07] **Tú:** [Sticker]

[22:07] **Tú:** [Mensaje de voz]

[22:08] **Maria. Valencia:**
> _Tú: y tienes alguna comida favorita mari?_
re basicona, el sushi

[22:08] **Maria. Valencia:** [Sticker]

[22:08] **Tú:**
> _Maria. Valencia: yo no me se mover nadita por ahi, eso si_
yo ando aprendiendo porque subo medio seguido porque tengo juegos de basquet

[22:08] **Tú:**
> _Maria. Valencia: re basicona, el sushi_
DIOS MIO

[22:08] **Tú:** que basica nadaaa

[22:08] **Maria. Valencia:** pero como de todo igual, no me quejo con nada

[22:08] **Tú:** amo el sushi

[22:08] **Maria. Valencia:** el que come de todo no pasa hambre

[22:08] **Tú:** ya se que vamos a comer un día

[22:08] **Tú:**
> _Maria. Valencia: el que come de todo no pasa hambre_
eso shi jsjsjsj

[22:08] **Maria. Valencia:** ahh en lineaa

[22:09] **Maria. Valencia:** nai la perdida era yo, pido perdón

[22:09] **Tú:**
> _Maria. Valencia: nai la perdida era yo, pido perdón_
tranquila que algun momento se puede cuadrar y nos vemos y comemos algo si te parece

[22:10] **Tú:** yo como te digo debo ir a puerto cabello a visitar mi familia y estaria cerca de valencia o si no un día en ccs

[22:10] **Maria. Valencia:** pos asi mejor entonce, ya tengo que ver que borro

[22:10] **Tú:** prefiero tu comodidad la verdad

[22:10] **Maria. Valencia:**
> _Tú: ya se que vamos a comer un día_
jaja pero duele comer sushi, yo nada mas conozco un lugar bueno aqui

[22:11] **Maria. Valencia:** porque ya se volvió comida rapida

[22:11] **Tú:**
> _Maria. Valencia: jaja pero duele comer sushi, yo nada mas conozco un lugar bueno aqui_
[Mensaje de voz]

[22:11] **Maria. Valencia:**
> _Tú: tranquila que algun momento se puede cuadrar y nos vemos y comemos algo si te parece_
[Sticker]

[22:12] **Maria. Valencia:** no me molesta subir tampoco, total que siempre ando viendo que hacer de nuevo

[22:12] **Maria. Valencia:** yo esta semana iba al puerto para la playa pero se me cayó

[22:12] **Tú:**
> _Maria. Valencia: yo esta semana iba al puerto para la playa pero se me cayó_
coye que chimbo

[22:13] **Tú:**
> _Maria. Valencia: no me molesta subir tampoco, total que siempre ando viendo que hacer de nuevo_
bueño ya tengo entendido eso ya mari y me imagino que si subes te quedas donde saray supongo, que ella vive donde? para no llevarte tan lejos

[22:13] **Maria. Valencia:**
> _Tú: Mensaje de voz_
ah tienes varias opciones, vas dandole reseñas?

[22:14] **Maria. Valencia:**
> _Tú: bueño ya tengo entendido eso ya mari y me imagino que si subes te quedas donde saray supongo, que ella vive donde? para no llevarte tan lejos_
[Sticker]

[22:14] **Maria. Valencia:** ella es de guatire

[22:14] **Tú:**
> _Maria. Valencia: ah tienes varias opciones, vas dandole reseñas?_
[Mensaje de voz]

[22:14] **Tú:**
> _Maria. Valencia: ella es de guatire_
ay mi ma.

[22:14] **Maria. Valencia:**
> _Tú: ay mi ma._
seee

[22:15] **Tú:**
> _Maria. Valencia: seee_
[Mensaje de voz]

[22:15] **Maria. Valencia:**
> _Tú: Mensaje de voz_
hay pa probar

[22:16] **Tú:**
> _Maria. Valencia: hay pa probar_
shi

[22:16] **Maria. Valencia:**
> _Tú: Mensaje de voz_
tranqui, yo tengo ya donde quedarme si me llego a quedar en caracas

[22:16] **Maria. Valencia:** tengo familia en coche tambien

[22:17] **Maria. Valencia:** enfim, y que es lo que te gusta a ti hacer?

[22:17] **Tú:**
> _Maria. Valencia: tranqui, yo tengo ya donde quedarme si me llego a quedar en caracas_
[Mensaje de voz]

[22:18] **Maria. Valencia:** ahora supongo yo que si eres mas de ver anime? o ves series

[22:18] **Tú:**
> _Maria. Valencia: ahora supongo yo que si eres mas de ver anime? o ves series_
[Mensaje de voz]

[22:19] **Tú:** [Mensaje de voz]

[22:20] **Tú:** Sao también lo vi Sword art online ps

[22:27] **Maria. Valencia:**
> _Tú: Mensaje de voz_
casi todo el mundo

[22:27] **Maria. Valencia:** yo estando fuera del mundo

[22:27] **Maria. Valencia:** JAJAJA

[22:28] **Maria. Valencia:** o sea si he visto algunos

[22:28] **Maria. Valencia:** pero hace añales naw

[22:28] **Maria. Valencia:**
> _Tú: Sao también lo vi Sword art online ps_
fijate que nunca me llamó la atencion jskdjsk

[22:28] **Maria. Valencia:** ese tuvo su boom

[22:29] **Maria. Valencia:** y de Naruto yo tuve como un trauma de pequeña

[22:29] **Maria. Valencia:** y le agarre miedo

[22:29] **Maria. Valencia:** desde entonces nunca probé verlo

[22:30] **Tú:**
> _Maria. Valencia: fijate que nunca me llamó la atencion jskdjsk_
es bueno y criticado pero si me eso llorar ese anime

[22:30] **Tú:** yo soy muy llorón viendo series películas o lo que sea

[22:30] **Tú:**
> _Maria. Valencia: y de Naruto yo tuve como un trauma de pequeña_
coyee y eso?

[22:31] **Tú:**
> _Maria. Valencia: desde entonces nunca probé verlo_
[Mensaje de voz]

[22:31] **Tú:** [Mensaje de voz]

[22:32] **Maria. Valencia:**
> _Tú: yo soy muy llorón viendo series películas o lo que sea_
por lo menos existen las emociones, asi es que vale la pena

[22:32] **Maria. Valencia:**
> _Tú: coyee y eso?_
no se que vi de pequeña, chismeando lo que hacia mi hermana

[22:32] **Maria. Valencia:** era de noche y estaba ella leyendo noc

[22:33] **Maria. Valencia:** y el panel me pareció horrible

[22:34] **Maria. Valencia:** nunca me dio curiosidad por revisitarlo a ver que era xdxd

[22:34] **Maria. Valencia:** igual uno de niño exagera mucho, pero fue

[22:34] **Maria. Valencia:**
> _Tú: Mensaje de voz_
ea hay juegos que si son buenos

[22:35] **Maria. Valencia:** yo recuerdo uno del wii

[22:35] **Maria. Valencia:**
> _Tú: Mensaje de voz_
jaja se complementa

[22:35] **Tú:** [Mensaje de voz]

[22:36] **Tú:**
> _Maria. Valencia: por lo menos existen las emociones, asi es que vale la pena_
obvioss

[22:36] **Maria. Valencia:** yo leo puro romance de todas formas jsksjs muy poquito me lanzo otra cosa

[22:36] **Maria. Valencia:** yo estaba hace unas semanas leyendo bleach

[22:37] **Maria. Valencia:** me achicopalo ver que el anime segun y que va mas rapido

[22:37] **Tú:**
> _Maria. Valencia: yo estaba hace unas semanas leyendo bleach_
eey tengo un amigo super fan de bleach y siempre me jode con verlo y creo que la ultima temporada fue un super boom

[22:37] **Tú:** tengo hasta las skins en el fortnite porque me gusta el protagonista aunque nunca me vi el anime

[22:37] **Tú:** [Sticker]

[22:37] **Tú:** que pecado

[22:37] **Tú:**
> _Maria. Valencia: yo leo puro romance de todas formas jsksjs muy poquito me lanzo otra cosa_
tienes alguno favorito?

[22:38] **Maria. Valencia:**
> _Tú: Mensaje de voz_
tampoco son malos los cliches, menos si vienen de una historia que claramente fue demasiado exitosa

[22:39] **Maria. Valencia:** mientras sea entretenido por lo menos

[22:39] **Tú:**
> _Maria. Valencia: mientras sea entretenido por lo menos_
si tienes razón en lo que dices mari

[22:40] **Maria. Valencia:**
> _Tú: tengo hasta las skins en el fortnite porque me gusta el protagonista aunque nunca me vi el anime_
es que el tipo es arrechito

[22:40] **Maria. Valencia:** y la historia es chula pero

[22:40] **Maria. Valencia:** si es el mas largo que estoy intentando leer

[22:40] **Maria. Valencia:** dio

[22:41] **Maria. Valencia:**
> _Tú: tienes alguno favorito?_
de romance seria kamisama kiss

[22:41] **Maria. Valencia:** tengo 3 tomos del arco que me gusta

[22:41] **Tú:** dejame felicitarte por ese gran hábito la verdad es uno que siempre me ha costado

[22:41] **Tú:** leer 😅😅

[22:41] **Maria. Valencia:**
> _Tú: que pecado_
bno yo tengo un estante con libros y pregúntame si los he leido

[22:42] **Maria. Valencia:** [Sticker]

[22:42] **Tú:**
> _Maria. Valencia: de romance seria kamisama kiss_
que te parece si lo empiezo a leer y te doy mi feedback y asi tenemos otro tema de que hablar?

[22:42] **Maria. Valencia:** jaja puro poser

[22:42] **Tú:**
> _Maria. Valencia: jaja puro poser_
[Sticker]

[22:42] **Maria. Valencia:**
> _Tú: que te parece si lo empiezo a leer y te doy mi feedback y asi tenemos otro tema de que hablar?_
JAJAJA

[22:42] **Maria. Valencia:** dicen que es aburrido

[22:42] **Maria. Valencia:** pero yo le tengo lindos recuerdos

[22:42] **Maria. Valencia:** cuando existia tumangaonline

[22:43] **Tú:**
> _Maria. Valencia: cuando existia tumangaonline_
ni idea cosas de gente que lee mangas supongo jsjsj

[22:43] **Tú:** tumbaron esa página?

[22:43] **Maria. Valencia:**
> _Tú: tumbaron esa página?_
siii

[22:43] **Maria. Valencia:** estan tumbando varias

[22:43] **Tú:**
> _Maria. Valencia: pero yo le tengo lindos recuerdos_
bueno confio en ti entonces

[22:43] **Maria. Valencia:** :(

[22:43] **Tú:**
> _Maria. Valencia: estan tumbando varias_
[Sticker]

[22:43] **Tú:** no puede seeer

[22:43] **Tú:** que pecado

[22:43] **Maria. Valencia:** y bno, otro que me cambio la vida asi

[22:43] **Maria. Valencia:** fue d gray man

[22:44] **Maria. Valencia:** ese si nadie lo conoce porque está mas muerto que la mama de tarzan

[22:45] **Maria. Valencia:** es de esos que actualizan cada 3 meses todavia

[22:45] **Maria. Valencia:** la autora como que le sigue los pasos a berserk

[22:46] **Tú:**
> _Maria. Valencia: la autora como que le sigue los pasos a berserk_
ese es bueno tmb no?

[22:46] **Tú:** he sabido poco de eso fue por el anime y cuando se hizo trend

[22:47] **Maria. Valencia:**
> _Tú: ese es bueno tmb no?_
es medio bizarro pero si se entiende el punto de la historia que intentan contar ps

[22:47] **Maria. Valencia:** yo sufri mucho leyéndolo

[22:47] **Tú:**
> _Maria. Valencia: es medio bizarro pero si se entiende el punto de la historia que intentan contar ps_
si mas o menos vi eso con lo de la novia/esposa no que era de guts

[22:47] **Maria. Valencia:** pero si le doy su mérito porque es compleja la historia

[22:47] **Tú:** y como el veía todo eso y no se que

[22:48] **Tú:** yo quede así

[22:48] **Tú:** [Sticker]

[22:48] **Maria. Valencia:** JAJAJAJ

[22:48] **Maria. Valencia:** si

[22:48] **Maria. Valencia:** es todo raro

[22:49] **Maria. Valencia:** pero es otro que estan intentando seguir

[22:49] **Tú:** todavía no han terminado no?

[22:49] **Tú:** el de kamisama si esta terminado no?

[22:49] **Maria. Valencia:**
> _Tú: todavía no han terminado no?_
nope

[22:50] **Maria. Valencia:** el autor falleció, pero el equipo es el que lo esta continuando

[22:50] **Maria. Valencia:**
> _Tú: el de kamisama si esta terminado no?_
sii

[22:50] **Maria. Valencia:** hace uff

[22:50] **Tú:**
> _Maria. Valencia: el autor falleció, pero el equipo es el que lo esta continuando_
ay

[22:50] **Tú:** [Sticker]

[22:50] **Tú:**
> _Maria. Valencia: hace uff_
ya ando buscando donde verlo

[22:50] **Maria. Valencia:** el anime es lindo

[22:51] **Maria. Valencia:** [Sticker]

[22:51] **Tú:** _Eliminaste este mensaje._

[22:51] **Tú:** [Imagen] este no?

[22:51] **Maria. Valencia:** sip

[22:51] **Tú:** se mando 2 veces my bad

[22:52] **Maria. Valencia:** ese mismo e

[22:52] **Tú:** que bueno entonces

[22:52] **Tú:** lo ire viendo con el tiempito y te voy dando mis feedback

[22:52] **Tú:** si me parece aburrido

[22:52] **Tú:** divertido y eso

[22:52] **Tú:** va?

[22:52] **Maria. Valencia:** siva

[22:53] **Tú:** eres mas de comer los tempura en el sushi

[22:53] **Tú:** o te gusta full sushi en general

[22:53] **Maria. Valencia:** me gusta en general, mas bien no soy muy fan del tempurizado

[22:53] **Maria. Valencia:** pero no hay queja tampoco

[22:54] **Maria. Valencia:** mira

[22:54] **Tú:** entonces sería mixta ese día

[22:54] **Tú:**
> _Maria. Valencia: mira_
miro

[22:55] **Maria. Valencia:** tu te considerarías supersticioso?

[22:55] **Maria. Valencia:** [Sticker]

[22:55] **Tú:**
> _Maria. Valencia: tu te considerarías supersticioso?_
jumm

[22:55] **Tú:** un poco

[22:55] **Maria. Valencia:** pero en qué

[22:56] **Maria. Valencia:** del tipo religioso, del destino, de la suerte

[22:57] **Maria. Valencia:** hay muchas creencias

[22:57] **Tú:**
> _Maria. Valencia: del tipo religioso, del destino, de la suerte_
bueno o sea, no es que ande pendiente de no cruzarme con un gato negro jaja, pero sí creo full en que las cosas pasan por algo, en el destino y en que las buenas energías atraen la buena suerte

[22:58] **Tú:** por ejemplo, yo soy católico por mi mamá, así que por ese lado va mi fe. Y con lo demás, siento que el destino se encarga de poner las cosas en su lugar.

[22:58] **Maria. Valencia:** oh vava, si entiendoo

[22:58] **Maria. Valencia:** un mix de todo

[22:58] **Tú:**
> _Maria. Valencia: un mix de todo_
tal cual, un mix es lo mejor al final se trata de tener buena vibra y creer en lo que te haga sentir bien. ¿Tú tienes algún amuleto o algo en lo que creas full?

[23:00] **Maria. Valencia:** yo por lo general me rehuso a creer en cosas de ese estilo

[23:01] **Maria. Valencia:** pero siempre me gusta escuchar otra perspectiva

[23:01] **Maria. Valencia:** sus razones y como se piensa

[23:02] **Tú:** bueno si eso es lo fino, que se pueda hablar de todo con confianza jajaja. Y bueno, para que veas que tampoco soy un extremista, yo no tengo pulseras ni amuletos de protección ni nada de eso, es más una forma de ver la vida. Al final, cada quien tiene su manera de encontrar su equilibrio si se podria decir de alguna forma

[23:02] **Maria. Valencia:** siii, total que estoy bn lejos del lado santero en mi familia

[23:03] **Maria. Valencia:** o ni siquiera se si lo siguen practicando

[23:03] **Maria. Valencia:** eso si que me parece raro pero

[23:03] **Maria. Valencia:** bno, pa gustos colores

[23:04] **Tú:** no, bueno, yo menos jajaja, la verdad nada que ver con la santería por mi parte pero mira, cambiando un pelo el tema que me dio curiosidad, ¿qué tipo de música escuchas tú por lo general? ¿O cuál es tu cantante favorito?

[23:05] **Maria. Valencia:** yo escucho puro pop chicloso jsksj lo que escucho por tiktok mas que todo

[23:06] **Maria. Valencia:** es muy poquito de otros géneros que escuche

[23:06] **Maria. Valencia:** creo que no tengo uno favorito ahorita

[23:06] **Maria. Valencia:** [Sticker]

[23:07] **Maria. Valencia:** pero estoy escuchando mas a una que se llama sailorr

[23:08] **Maria. Valencia:** flo, sabrina, tate

[23:08] **Tú:**
> _Maria. Valencia: pero estoy escuchando mas a una que se llama sailorr_
la que es como chinita no?

[23:08] **Maria. Valencia:**
> _Tú: la que es como chinita no?_
sii

[23:08] **Tú:** yo escuche una que me gusto

[23:08] **Maria. Valencia:** que siempre carga los grills negros

[23:08] **Tú:** se llama coconut

[23:08] **Maria. Valencia:** ajaa, esa misma

[23:08] **Tú:** que buen tema la verdad

[23:08] **Tú:**
> _Maria. Valencia: ajaa, esa misma_
que loco no?

[23:09] **Tú:** jsjjsjs

[23:09] **Tú:**
> _Maria. Valencia: flo, sabrina, tate_
sabrina carpenter imagino no?

[23:09] **Maria. Valencia:** sip

[23:09] **Tú:** eyyy que buenos gustos mariii

[23:09] **Maria. Valencia:** [Sticker]

[23:10] **Maria. Valencia:** yo siempre cargo los audifonos

[23:10] **Tú:**
> _Maria. Valencia: yo siempre cargo los audifonos_
yoooo

[23:10] **Tú:** me dio risa

[23:10] **Maria. Valencia:** y tu que escuchas??

[23:10] **Tú:** que en nuestras fotos de cosplay teníamos audífonos los 2

[23:10] **Tú:**
> _Maria. Valencia: Sticker_
[Sticker]

[23:11] **Maria. Valencia:**
> _Tú: que en nuestras fotos de cosplay teníamos audífonos los 2_
si??

[23:11] **Maria. Valencia:** no me di cuenta

[23:11] **Tú:**
> _Maria. Valencia: si??_
no osea alli no

[23:12] **Tú:** en nuestras fotos solitarios

[23:12] **Maria. Valencia:** ahh asi sii

[23:12] **Maria. Valencia:** JAJAJ

[23:12] **Maria. Valencia:** si los cargaba

[23:12] **Tú:**
> _Maria. Valencia: y tu que escuchas??_
bueñoo yo escucho un mix de todo un poco la verdad en la onda pop, mis favoritos fijos de siempre son Justin Bieber y Ariana Grande, así que por ahí coincidimos seguro jajaja. Pero también le meto full al reggaetón y al trap

[23:13] **Tú:** [Imagen]

[23:13] **Tú:** [Imagen] el menos observador y tal jsjsjs

[23:13] **Tú:** [Imagen] el menos observador y tal jsjsjs

[23:13] **Maria. Valencia:**
> _Tú: Imagen_
AHHH

[23:13] **Maria. Valencia:** ya te iba a preguntar

[23:13] **Maria. Valencia:** ya me parecía raro

[23:13] **Maria. Valencia:** JAJAJ

[23:13] **Tú:**
> _Maria. Valencia: ya me parecía raro_
[Sticker]

[23:14] **Maria. Valencia:**
> _Tú: bueñoo yo escucho un mix de todo un poco la verdad en la onda pop, mis favoritos fijos de siempre son Justin Bieber y Ariana Grande, así que por ahí coincidimos seguro jajaja. Pero también le meto full al reggaetón y al trap_
si, en efecto jsksj

[23:14] **Maria. Valencia:** yo al reggae ni al trap le voy mucho pero

[23:14] **Maria. Valencia:** con mucho respect

[23:14] **Maria. Valencia:** es lo que mas se disfruta en la disco igual

[23:14] **Tú:**
> _Maria. Valencia: yo al reggae ni al trap le voy mucho pero_
tranquila para gustos colores como me dijiste

[23:15] **Tú:** [Imagen] bueno este es mi mood ahorita jsjsjs

[23:22] **Maria. Valencia:** [Sticker]

[23:22] **Maria. Valencia:** una vibra

[23:22] **Maria. Valencia:** mira y

[23:23] **Maria. Valencia:** tienes una peli o algo al que tengas gusto culposo?

[23:23] **Maria. Valencia:** de esas que es tan malo que se vuelve bueno

[23:23] **Maria. Valencia:** yo soy fan de ver pelis asi

[23:23] **Maria. Valencia:** malas pero entretenidas

[23:24] **Maria. Valencia:** a mi normalmente ni me dejan elegir películas por eso, en la rara ocasión que se vea

[23:25] **Tú:** Wow

[23:25] **Tú:** jsjsjsj

[23:26] **Tú:**
> _Maria. Valencia: tienes una peli o algo al que tengas gusto culposo?_
jajajaja no me lo esperaba 😂. O sea que te tienen censurada con el control remoto. Bueno, para mí un gusto culposo fijo es Son como niños es que es buenísima. ¿Pero a ver, cuál es esa peli tan mala que te encanta y por la que no te dejan elegir?

[23:27] **Tú:** o bueno ¿Cuál es esa película tuya con la que la gente dice 'ya va, qué es esto' pero tú te la disfrutas?

[23:33] **Maria. Valencia:** berro

[23:33] **Maria. Valencia:** miss shampoo

[23:33] **Maria. Valencia:** y esa la vi este año

[23:34] **Maria. Valencia:** pero venció a todas

[23:34] **Maria. Valencia:** JAJAJ

[23:35] **Tú:** naguara berro, me mataste, no tengo ni la más mínima idea de cuál es esa película 😂. ¿De qué trata? ¿Por qué venció a todas las pelis malas? Ahora me dio curiosidad jajaja

[23:35] **Maria. Valencia:** es china la peli

[23:36] **Maria. Valencia:** de un mafioso que cae en la peluquería y se enamora de la chama

[23:36] **Maria. Valencia:** el tipo empieza a ir seguido a que le arregle el cabello y aja

[23:36] **Maria. Valencia:** pero pasan unas vainas

[23:37] **Maria. Valencia:** porque la tipa tambien esta aprendiendo

[23:37] **Maria. Valencia:** y hasta novio tiene al principio de la peli

[23:37] **Tú:**
> _Maria. Valencia: y hasta novio tiene al principio de la peli_
NAGUARAAAAA

[23:37] **Tú:** JDKSADJKASKSAJDSAJ

[23:38] **Tú:** ni la he visto y me dio curiosidad y me hizo la noche con lo random que es jsjjs

[23:38] **Maria. Valencia:** si vale, es buena porque se ve que la hicieron para que no se tome tan en serio

[23:39] **Tú:**
> _Maria. Valencia: si vale, es buena porque se ve que la hicieron para que no se tome tan en serio_
[Mensaje de voz]

[23:41] **Maria. Valencia:** es que son esos detalles que tmb importan

[23:41] **Maria. Valencia:** porque imaginate que solo vieras pelis de culto

[23:41] **Maria. Valencia:** que si el señor de los anillos, dune

[23:42] **Maria. Valencia:** noc cuales mas

[23:42] **Tú:**
> _Maria. Valencia: que si el señor de los anillos, dune_
esa no me la he visto

[23:42] **Tú:** ni game of thrones

[23:42] **Maria. Valencia:** y no pudieras aguantarte verte norbit

[23:42] **Tú:** aunque eso es serie creo

[23:42] **Maria. Valencia:** o donde estan las rubias

[23:42] **Tú:**
> _Maria. Valencia: y no pudieras aguantarte verte norbit_
DIOSSSS

[23:42] **Tú:** jajajajajajaj

[23:42] **Maria. Valencia:** o una romántica de esas cliches pero horribles

[23:43] **Maria. Valencia:** como fabricante de lagrimas

[23:43] **Maria. Valencia:** es malisima

[23:43] **Tú:** [Mensaje de voz]

[23:43] **Maria. Valencia:** pero recuerdo cuando la vi, porque fue con amigas, era un vacilón

[23:44] **Maria. Valencia:**
> _Tú: Mensaje de voz_
:000

[23:44] **Tú:**
> _Maria. Valencia: pero recuerdo cuando la vi, porque fue con amigas, era un vacilón_
imagino la verdad jsjsjs

[23:44] **Tú:**
> _Maria. Valencia: :000_
te lo juro que yo estaba asi

[23:44] **Tú:** [Sticker]

[23:44] **Maria. Valencia:**
> _Tú: Mensaje de voz_
muy basada la verda

[23:44] **Maria. Valencia:** JAJAJAJ

[23:45] **Tú:** [Mensaje de voz]

[23:47] **Maria. Valencia:** JAJAJ

[23:47] **Maria. Valencia:** wa esta fino tambien

[23:47] **Maria. Valencia:** por este lado

[23:48] **Maria. Valencia:** y que haces ahorita?

[23:48] **Tú:**
> _Maria. Valencia: por este lado_
como ashi?

[23:48] **Maria. Valencia:** yo ya estoy puesta para dormir

[23:48] **Maria. Valencia:**
> _Tú: como ashi?_
bno de mi parte, que todo va calidad contigo

[23:49] **Maria. Valencia:** [Sticker]

[23:49] **Tú:**
> _Maria. Valencia: y que haces ahorita?_
pues a parte de hablar contigo escuchar música en la computadora mientras termino un trabajo de un cambio de menú para justamente para empresa de sushi

[23:49] **Tú:**
> _Maria. Valencia: bno de mi parte, que todo va calidad contigo_
que bueno mari, excelente

[23:50] **Maria. Valencia:**
> _Tú: pues a parte de hablar contigo escuchar música en la computadora mientras termino un trabajo de un cambio de menú para justamente para empresa de sushi_
oww vava, te falta mucho?

[23:50] **Tú:**
> _Maria. Valencia: oww vava, te falta mucho?_
ni tanto

[23:50] **Tú:** ponte que 10/15 minutos

[23:51] **Tú:**
> _Maria. Valencia: yo ya estoy puesta para dormir_
[Mensaje de voz]

---

## 4 de noviembre de 2026

[0:03] **Maria. Valencia:** ya ahora si estoy por dormir

[0:03] **Maria. Valencia:** mañana me toca levantarme temprano

[0:03] **Maria. Valencia:** yo si tengo el horario hecho ñoña

[0:04] **Tú:**
> _Maria. Valencia: ya ahora si estoy por dormir_
[Mensaje de voz]

[0:04] **Maria. Valencia:** como yo trabajo rotando a veces es dificil conciliar el sueño

[0:04] **Tú:**
> _Maria. Valencia: como yo trabajo rotando a veces es dificil conciliar el sueño_
entiendo yo duermo tarde ya por costumbre

[0:05] **Maria. Valencia:**
> _Tú: Mensaje de voz_
dale graciass ♡

[0:05] **Maria. Valencia:** que logres descansar igual cuando termines

[0:05] **Maria. Valencia:** chau

[0:06] **Tú:**
> _Maria. Valencia: que logres descansar igual cuando termines_
igual muchas gachasss

[0:06] **Tú:**
> _Maria. Valencia: chau_
chauu

[10:59] **Tú:** holaa, mari buenos días como estas? yo recien me levanto

[12:06] **Maria. Valencia:** holahola

[12:06] **Maria. Valencia:** yo me desperté hace rato tambien

[12:06] **Maria. Valencia:** hasta se me pasó que iba temprano al gym

[12:07] **Maria. Valencia:** supongo me tocará ir mañana trasnochada

[12:07] **Maria. Valencia:** [Sticker]

[12:07] **Maria. Valencia:** y tu como estás?

[12:11] **Tú:**
> _Maria. Valencia: hasta se me pasó que iba temprano al gym_
[Sticker]

[12:12] **Tú:**
> _Maria. Valencia: supongo me tocará ir mañana trasnochada_
porque hoy entras tarde y  sales en la mañanita no?

[12:13] **Tú:**
> _Maria. Valencia: y tu como estás?_
bien ya desayune me levante y mi mama compro una mini pizza y me la dejo allí ya que me quede solo hoy y aproveche de actualizar todos mis pesos y como voy subiendo en los ejercicios y volver a actualizar el menú de los sushi porque cambiaron algo mas

[12:14] **Tú:** y mas tarde como en 30/40 minutos me hago el almuerzo y el batido que me tomo luego de entrenar

[12:14] **Tú:** y tu como te sientes? con sueño descansaste bien que tal?

[17:02] **Maria. Valencia:**
> _Tú: porque hoy entras tarde y  sales en la mañanita no?_
sii, salgo mañana a las 6am

[17:04] **Maria. Valencia:**
> _Tú: y mas tarde como en 30/40 minutos me hago el almuerzo y el batido que me tomo luego de entrenar_
[Sticker]

[17:04] **Maria. Valencia:** ea y que es lo mas elaborado que te has hecho? si te gusta cocinar o ajá, para sobrevivir?

[17:05] **Maria. Valencia:**
> _Tú: y tu como te sientes? con sueño descansaste bien que tal?_
todavia tengo sueño y eso que me volvi a dormir para agarrar mejor energía para la noche

[17:08] **Tú:**
> _Maria. Valencia: ea y que es lo mas elaborado que te has hecho? si te gusta cocinar o ajá, para sobrevivir?_
tampoco es como que me de una super mala vida en cocinar es mas que todo para sobrevivir o cuando estoy aburrido hago algo mas elaborado

[17:14] **Maria. Valencia:** jaja algo es algo

[17:14] **Tú:** Una de mis comidas que me gusta hacer es que si pasta con salsa bechamel y le hecho su aliñito y eso. Y algo sencillo pero que tiene su maña para que quede bien es clavarle un buen pollo a la plancha que quede jugoso y no seco, o un buen arroz sazonado. ¿A ti qué tal se te da la cocina?

[17:15] **Tú:**
> _Maria. Valencia: todavia tengo sueño y eso que me volvi a dormir para agarrar mejor energía para la noche_
ay imagino yo ahorita ando en el gym y creo que apenas salga debo ir a ccs porque tengo juego de basket y me llamaron de urgencia🫩

[17:22] **Tú:** [Imagen] mood:estresado 

la tobillera en el brazo es para poder hacer laterales jsjsjs

[17:22] **Maria. Valencia:**
> _Tú: Una de mis comidas que me gusta hacer es que si pasta con salsa bechamel y le hecho su aliñito y eso. Y algo sencillo pero que tiene su maña para que quede bien es clavarle un buen pollo a la plancha que quede jugoso y no seco, o un buen arroz sazonado. ¿A ti qué tal se te da la cocina?_
yo digo que bien jsksj aunque yo solo cocino en ocasiones

[17:22] **Tú:** [Imagen] mood:estresado 

la tobillera en el brazo es para poder hacer laterales jsjsjs

[17:23] **Maria. Valencia:** o hago postres, en esa si me destaco mas

[17:24] **Maria. Valencia:** aunque en esa si voy aprendiendo poco a poco, a veces no me salen los inventos

[17:24] **Maria. Valencia:**
> _Tú: ay imagino yo ahorita ando en el gym y creo que apenas salga debo ir a ccs porque tengo juego de basket y me llamaron de urgencia🫩_
pero pero ya te tienen en un equipo o es que faltó otro?

[17:26] **Maria. Valencia:**
> _Tú: Imagen: mood:estresado 

la tobillera en el brazo es para poder hacer laterales jsjsjs_
bno pero con calma, con tal que no te lastimes

[17:26] **Maria. Valencia:** estresado nada se mueve mas rápido

[17:27] **Tú:**
> _Maria. Valencia: pero pero ya te tienen en un equipo o es que faltó otro?_
tengo mi equipo pero otro equipo me llamo de refuerzo para el suyo

[17:27] **Tú:**
> _Maria. Valencia: estresado nada se mueve mas rápido_
tienes razón y no tranquila la tobillera es porque como lo hago en polea uso mi brazo para alzar y no el agarre porque se me cansaría primero la mano que el hombro

[17:27] **Tú:**
> _Maria. Valencia: aunque en esa si voy aprendiendo poco a poco, a veces no me salen los inventos_
ayy jsjsj

[17:28] **Tú:**
> _Maria. Valencia: o hago postres, en esa si me destaco mas_
que bueno marii

[17:28] **Tú:**
> _Maria. Valencia: aunque en esa si voy aprendiendo poco a poco, a veces no me salen los inventos_
tranquila todo es un proceso

[17:31] **Maria. Valencia:**
> _Tú: tengo mi equipo pero otro equipo me llamo de refuerzo para el suyo_
ow va, el deber llama tons

[17:31] **Maria. Valencia:** [Sticker]

[17:34] **Tú:**
> _Maria. Valencia: ow va, el deber llama tons_
literalmente bueño ya te respondo o algo terminaré aca

[17:43] **Maria. Valencia:** valevale

[18:08] **Tú:** listop

[18:09] **Tú:** [Imagen] ahora a tomarme el batido para irme😅 y tu a que hora entras al trabajo?

[18:09] **Tú:** [Imagen] ahora a tomarme el batido para irme😅 y tu a que hora entras al trabajo?

[18:10] **Tú:** hoy me toco hacer espalda hombro y triceps que te tocaría hacer a ti? aunque lastimosamente amanecida

[18:16] **Maria. Valencia:**
> _Tú: Imagen: ahora a tomarme el batido para irme😅 y tu a que hora entras al trabajo?_
[Imagen] ya estoy

[18:17] **Maria. Valencia:**
> _Tú: Imagen: ahora a tomarme el batido para irme😅 y tu a que hora entras al trabajo?_
[Imagen] ya estoy

[18:17] **Maria. Valencia:** [Imagen]

[18:17] **Maria. Valencia:** [Imagen]

[18:17] **Maria. Valencia:**
> _Tú: hoy me toco hacer espalda hombro y triceps que te tocaría hacer a ti? aunque lastimosamente amanecida_
femoral y glúteos según

[18:21] **Tú:**
> _Maria. Valencia: Imagen: ya estoy_
eshoo una mujer trabajadora y estas muy linda aunque no te he visto como tal hoy, no necesito hacerlo para confirmar lo linda que estas🫶🏽

[18:22] **Tú:**
> _Maria. Valencia: femoral y glúteos según_
ahh bueno esta bien ya veras que todo te saldrá bien confio en ti

[18:23] **Tú:**
> _Maria. Valencia: Imagen: ya estoy_
y suerte en tu trabajo te deseo lo mejor y tambien sea un buen día asi que concentrada alli me avisas cualquier cosa, y yo te aviso cuando me toque jugar asi sabes por si no contesto

[19:35] **Tú:**
> _Tú: y suerte en tu trabajo te deseo lo mejor y tambien sea un buen día asi que concentrada alli me avisas cualquier cosa, y yo te aviso cuando me toque jugar asi sabes por si no contesto_
ya me toca jugar hablamos luego, suerteeee

---

## 5 de noviembre de 2026

[0:36] **Maria. Valencia:** heyo

[0:37] **Maria. Valencia:** que tal el juego??

[0:37] **Maria. Valencia:** yo voy cenando apenitas

[0:37] **Maria. Valencia:** aparentemente no hay mucho que hacer pero

[0:49] **Tú:**
> _Maria. Valencia: yo voy cenando apenitas_
esoo buen provechoo

[0:49] **Tú:**
> _Maria. Valencia: que tal el juego??_
ganamos y ahorita estoy con mis amigos jugando pool

[0:49] **Tú:** que comes mari?

[0:49] **Tú:** [Mensaje de video]

[0:50] **Tú:** como para celebrar se podria decir

[0:51] **Tú:** y de aquí vamos a la casa de mi amigo y bajo temprano mañana, me fui con 12 puntos 6 asistencias y 8 rebotes hice mi chamba como quien dice

[3:43] **Tú:**
> _Tú: y de aquí vamos a la casa de mi amigo y bajo temprano mañana, me fui con 12 puntos 6 asistencias y 8 rebotes hice mi chamba como quien dice_
holaa te informo bueno, para por si algo sepas ya estoy en casa de mi amigo hace rato pedimos un taxi del pool hasta aca y bueno estoy en un lugar seguro y tranquilo espero te este yendo bien, feliz madrugada

[4:48] **Maria. Valencia:** yo recién vengo terminandooi

[4:48] **Maria. Valencia:** [Sticker]

[4:50] **Maria. Valencia:**
> _Tú: y de aquí vamos a la casa de mi amigo y bajo temprano mañana, me fui con 12 puntos 6 asistencias y 8 rebotes hice mi chamba como quien dice_
awe me alegra que les haya ido tan bn

[4:51] **Maria. Valencia:** ojala algun dia poder verlos y ver que tal

[4:52] **Maria. Valencia:** aca estamos esperando la hora de salida para marcar

[4:53] **Maria. Valencia:**
> _Tú: Mensaje de video_
ea nunca he podido jugar tampoco

[4:53] **Maria. Valencia:** la vez que iba recuerdo que no dejaron entrar a un amigo y nos fuimos

[4:55] **Maria. Valencia:**
> _Tú: holaa te informo bueno, para por si algo sepas ya estoy en casa de mi amigo hace rato pedimos un taxi del pool hasta aca y bueno estoy en un lugar seguro y tranquilo espero te este yendo bien, feliz madrugada_
que descanses entonces! y puedas dormir algo para tener mas ánimos hoy, que no falta mucho tampoco jskdj

[5:07] **Tú:**
> _Maria. Valencia: yo recién vengo terminandooi_
que bueñoo jsjsj

[5:07] **Tú:**
> _Maria. Valencia: ojala algun dia poder verlos y ver que tal_
si algun dia tranquila no te preocupes

[5:08] **Tú:** gracias por tu receptividad

[5:09] **Tú:**
> _Maria. Valencia: ea nunca he podido jugar tampoco_
estabamos en un salón v.i.p 8$ la hora el próximo finde si dios quiere podemos hacer de todo tengo unos planes en mente cuando nos veamos

[5:09] **Tú:**
> _Maria. Valencia: la vez que iba recuerdo que no dejaron entrar a un amigo y nos fuimos_
ayyy que chimbo mari

[5:10] **Tú:**
> _Maria. Valencia: que descanses entonces! y puedas dormir algo para tener mas ánimos hoy, que no falta mucho tampoco jskdj_
anda igualmente y bueno si logras ir al gym ojalá todo te salga bien mari estoy orgulloso de ti y como tienes ese ritmo de vida un poco complicado y lo resiliente que eres

[5:11] **Tú:** yo no he dormido ahorita como a las 7 am lanze balon un rato y practique y ya cuando baje a la guaira duermo bien y seguir con la rutina la verdad hoy si jodi mi horario😅😅

[7:00] **Maria. Valencia:**
> _Tú: estabamos en un salón v.i.p 8$ la hora el próximo finde si dios quiere podemos hacer de todo tengo unos planes en mente cuando nos veamos_
[Sticker]

[7:00] **Maria. Valencia:**
> _Tú: anda igualmente y bueno si logras ir al gym ojalá todo te salga bien mari estoy orgulloso de ti y como tienes ese ritmo de vida un poco complicado y lo resiliente que eres_
jakdjsk si, ya voy en camino

[7:01] **Maria. Valencia:** ya me daba vaina faltarle a la entrenadora

[7:01] **Maria. Valencia:**
> _Tú: yo no he dormido ahorita como a las 7 am lanze balon un rato y practique y ya cuando baje a la guaira duermo bien y seguir con la rutina la verdad hoy si jodi mi horario😅😅_
jaja pero que fue? se pusieron a hablar?

[7:02] **Tú:**
> _Maria. Valencia: jaja pero que fue? se pusieron a hablar?_
[Imagen] jugando play

[7:02] **Tú:** estoy terminando de jugar basket en el play para entrenar ahorita estaba esperando que abrieran la cancha

[7:02] **Tú:**
> _Maria. Valencia: ya me daba vaina faltarle a la entrenadora_
aah tienes entrenadora?

[7:02] **Tú:**
> _Maria. Valencia: jakdjsk si, ya voy en camino_
esoo que bueno

[7:05] **Tú:** [Mensaje de voz]

[7:24] **Maria. Valencia:**
> _Tú: Imagen: jugando play_
ah vale jaja, que rela

[7:24] **Maria. Valencia:**
> _Tú: aah tienes entrenadora?_
sii

[7:25] **Maria. Valencia:** porque yo nunca he hecho ejercicio

[7:25] **Maria. Valencia:** tengo apenitas un mes

[7:26] **Maria. Valencia:**
> _Tú: Mensaje de voz_
con mucho cuidado tons

[7:26] **Maria. Valencia:** [Sticker]

[7:27] **Tú:**
> _Maria. Valencia: tengo apenitas un mes_
ahh que bueno que hayas empezado a agarrar ese hábito

[7:27] **Tú:**
> _Maria. Valencia: con mucho cuidado tons_
tranquila yo me cuido porque si no luego como te sigo conociendo? jsjsjs

[7:27] **Tú:**
> _Maria. Valencia: con mucho cuidado tons_
andaa suerte en el gym

[7:27] **Tú:** [Sticker]

[16:42] **Maria. Valencia:** heyo

[16:42] **Maria. Valencia:** ya de nuevo estoy esperando el transporte, es mi ultima noche ah

[16:42] **Maria. Valencia:** yo esta mañana iba a pata quemada porque llegue a mi casa e hice todo rapido jaja

[16:42] **Maria. Valencia:** tengo mucho sueño igual

[16:42] **Maria. Valencia:** y a ti como te esta yendo??

[16:44] **Tú:**
> _Maria. Valencia: y a ti como te esta yendo??_
heyooo

[16:45] **Tú:** bueno fui directo al gym osea de caracas me baje en el gym de la guaira (y confirmo tu estado ir amanecido es lo peor) ya llegue hace como 2 hr por alli almorcé y me tome y ahorita estoy recostado

[16:47] **Tú:**
> _Maria. Valencia: tengo mucho sueño igual_
imagino, imagino espero hayas logrado descansar un poco yo apenas caiga voy a estar un rato durmiendo jsjsjs

[16:47] **Maria. Valencia:** [Sticker]

[16:47] **Tú:**
> _Maria. Valencia: ya de nuevo estoy esperando el transporte, es mi ultima noche ah_
esoo ya viene tu fin de semana en el que puedes descansar y estar mas cómoda mari que bueno eso ♡

[16:57] **Maria. Valencia:**
> _Tú: bueno fui directo al gym osea de caracas me baje en el gym de la guaira (y confirmo tu estado ir amanecido es lo peor) ya llegue hace como 2 hr por alli almorcé y me tome y ahorita estoy recostado_
jajaj siento que el dia ha sido demasiado largo también

[16:58] **Maria. Valencia:**
> _Tú: esoo ya viene tu fin de semana en el que puedes descansar y estar mas cómoda mari que bueno eso ♡_
see, ya de aqui estoy libre hasta el martes mas o menitos

[16:58] **Maria. Valencia:** y que te tocó hoy ps?

[17:09] **Tú:**
> _Maria. Valencia: y que te tocó hoy ps?_
pecho y biceps

[17:09] **Tú:**
> _Maria. Valencia: see, ya de aqui estoy libre hasta el martes mas o menitos_
esta bien que bueno hoy tienes el mismo horario que ayer?

[17:10] **Tú:**
> _Maria. Valencia: y que te tocó hoy ps?_
y tu iras hoy? o lo tomas de descanso lo digo por tu horario y eso

[17:10] **Tú:**
> _Maria. Valencia: jajaj siento que el dia ha sido demasiado largo también_
siii yo tambien he notado como el día lento como si las hora pesaran mas sabes?

[18:05] **Maria. Valencia:**
> _Tú: esta bien que bueno hoy tienes el mismo horario que ayer?_
sip, ya mañana salgo libre

[18:05] **Maria. Valencia:**
> _Tú: y tu iras hoy? o lo tomas de descanso lo digo por tu horario y eso_
hoy? ya fuii

[18:05] **Maria. Valencia:** mañana si voy, pero en la noche

[18:05] **Tú:**
> _Maria. Valencia: hoy? ya fuii_
[Sticker]

[18:05] **Tú:** estoy super ido

[18:05] **Tú:** mala mia

[18:05] **Tú:** si es verdad que fuiste que si super temprano

[18:06] **Tú:**
> _Maria. Valencia: mañana si voy, pero en la noche_
ahh esta bien, esta bien tranqui

[18:08] **Maria. Valencia:**
> _Tú: siii yo tambien he notado como el día lento como si las hora pesaran mas sabes?_
[Sticker]

[18:09] **Maria. Valencia:** esta horrible el paso de los dias

[18:09] **Tú:** si en dado caso no te contesto es que caí dormido ando asi:

[18:09] **Tú:** [Sticker]

[18:09] **Tú:**
> _Tú: Sticker_
dato un poco curioso soy yo pero versión stickers aveces como no conseguí algo como tal para expresarme me tire una foto y con ayuda de la IA hice mis propios stickers

[18:10] **Tú:**
> _Maria. Valencia: esta horrible el paso de los dias_
bastante

[20:49] **Maria. Valencia:**
> _Tú: dato un poco curioso soy yo pero versión stickers aveces como no conseguí algo como tal para expresarme me tire una foto y con ayuda de la IA hice mis propios stickers_
jsksjs no hay nada como hacer las cosas uno

[20:50] **Maria. Valencia:** descansa full entonce, ya mañana vas con todo

[22:00] **Tú:** heyooo

[22:00] **Tú:** volvi

[22:00] **Tú:** me levantaron para cenar y comi una arepita frita con jamon y queso y un jugo de durazno

[22:01] **Tú:** y tenían unos msg de un cliente voy a ver si termino eso y no tengo mas nada para ver que hago y si sigo durmiendo

[22:01] **Tú:**
> _Maria. Valencia: descansa full entonce, ya mañana vas con todo_
graciass y tu que tal el día de hoy? ha sido movido, esta apagado y sabes que comerás en tu hora de break?

[22:34] **Maria. Valencia:**
> _Tú: y tenían unos msg de un cliente voy a ver si termino eso y no tengo mas nada para ver que hago y si sigo durmiendo_
[Sticker]

[22:35] **Maria. Valencia:**
> _Tú: graciass y tu que tal el día de hoy? ha sido movido, esta apagado y sabes que comerás en tu hora de break?_
prob pollo y ensalada

[22:35] **Maria. Valencia:** y esta yendo tranquilo

[22:35] **Maria. Valencia:** parece haber burda de adelantos

[22:35] **Maria. Valencia:** hoy probablemente no me dejen pegar el ojo ni por asomo

[22:35] **Maria. Valencia:** [Sticker]

[22:36] **Maria. Valencia:** _Esperando el mensaje… Esto puede demorar un poco._

[22:37] **Tú:**
> _Maria. Valencia: prob pollo y ensalada_
coye que buenoo

[22:37] **Tú:**
> _Maria. Valencia: hoy probablemente no me dejen pegar el ojo ni por asomo_
ay

[22:37] **Tú:** [Sticker]

[22:40] **Tú:**
> _Maria. Valencia: Imagen_
que linda mari, y como llegaste a entrar en ese trabajo?

[22:41] **Maria. Valencia:** eso fueee

[22:41] **Maria. Valencia:** como hace 3 años

[22:41] **Maria. Valencia:** por computrabajo

[22:41] **Maria. Valencia:** y aprendiendo de los veteranos acá porque

[22:41] **Maria. Valencia:** todo es movido

[22:42] **Maria. Valencia:** se sirven a 600 polares de dia y como 300 de noche

[22:42] **Tú:**
> _Maria. Valencia: se sirven a 600 polares de dia y como 300 de noche_
[Sticker]

[22:42] **Tú:** naguara

[22:43] **Tú:**
> _Maria. Valencia: por computrabajo_
ahh si se que es eso yo en mis tiempos de buscar trabajo como loco busque alli

[22:43] **Tú:**
> _Maria. Valencia: y aprendiendo de los veteranos acá porque_
claro, claro aprender de quien sabe

[22:43] **Maria. Valencia:**
> _Tú: Sticker_
seee

[22:43] **Maria. Valencia:** JAKSJ

[22:44] **Maria. Valencia:**
> _Tú: ahh si se que es eso yo en mis tiempos de buscar trabajo como loco busque alli_
sii, asi estaba yo

[22:58] **Tú:**
> _Maria. Valencia: sii, asi estaba yo_
imagino y tu que estudiaste como tal?

[22:58] **Tú:**
> _Maria. Valencia: seee_
literalmente mi reacción andas en un full movimiento entonces jsjsj

[22:58] **Tú:** yo ya ando aca terminando estas cosas

[23:00] **Maria. Valencia:**
> _Tú: imagino y tu que estudiaste como tal?_
mira depende de como lo veas

[23:00] **Maria. Valencia:** yo solo soy humildemente bachiller

[23:00] **Maria. Valencia:** y me certifiqué nomas como chef

[23:01] **Tú:** ohh esta super bien eso de chef

[23:01] **Tú:** te puede abrir puertas a muchas cosas la verdad

[23:02] **Tú:**
> _Maria. Valencia: mira depende de como lo veas_
tranquila que estoy para escucharte y conocerte jamás para juzgar

[23:02] **Maria. Valencia:**
> _Tú: literalmente mi reacción andas en un full movimiento entonces jsjsj_
[Imagen] full acción

[23:02] **Maria. Valencia:**
> _Tú: literalmente mi reacción andas en un full movimiento entonces jsjsj_
[Imagen] full acción

[23:02] **Tú:**
> _Maria. Valencia: Imagen: full acción_
ay ñomioo

[23:07] **Tú:**
> _Maria. Valencia: Imagen_
[Imagen] mi mood mientras

[23:07] **Maria. Valencia:**
> _Tú: Imagen: mi mood mientras_
enfocao

[23:07] **Tú:** pero bueno estoy por aca si necesitas algo tampoco te quiero distraer en tu trabajo

[23:07] **Maria. Valencia:** nai estoy echando carro

[23:08] **Tú:** ahhh bueno entonces chevere

[23:08] **Tú:** y cual es color favorito mari? nunca lo pregunte

---

## 6 de noviembre de 2026

[0:12] **Tú:** [Mensaje de video]

[6:14] **Maria. Valencia:** en efecto no se veia casi nada

[6:14] **Maria. Valencia:** [Sticker]

[6:14] **Maria. Valencia:** buenos dias ♡

[6:15] **Maria. Valencia:** que tal dormiste?

[6:15] **Maria. Valencia:**
> _Tú: y cual es color favorito mari? nunca lo pregunte_
es el naranja jsksj, que tal el tuyo?

[6:16] **Maria. Valencia:** lo chimbo es que no tengo muchas cosas de ese color, mi batidora, algunos utensilios y asi

[6:16] **Maria. Valencia:** pero de ropa siento que no me queda bien

[6:17] **Maria. Valencia:** pero es de ese naranja que sale en el cielo, cuando amanece o esta por anochecer tmb

[8:11] **Tú:**
> _Maria. Valencia: buenos dias ♡_
buenos diasss♡

[8:11] **Tú:**
> _Maria. Valencia: que tal dormiste?_
a la proxima intentare que los foto video sean con luz jsjsj y bien se podria decir ya me siento mucho mejor en lo que energías respecta, la verdad

[8:12] **Tú:**
> _Maria. Valencia: es el naranja jsksj, que tal el tuyo?_
el azul

[8:13] **Tú:**
> _Maria. Valencia: lo chimbo es que no tengo muchas cosas de ese color, mi batidora, algunos utensilios y asi_
ohhh yaya que lindo color la verdad creo que nunca habia escuchado alguien nombrar el naranja como su color preferido

[8:14] **Tú:**
> _Maria. Valencia: pero es de ese naranja que sale en el cielo, cuando amanece o esta por anochecer tmb_
ohh sisi entiendo eso una maña que tengo le tiro foto a algunos paisajes y eso y veo que tu tambien jsjsj

[8:14] **Tú:** tu como estas ya llegaste o algo? supongo que estas dormida o algo ya que no te caen los msg ojala descanses y estés bien espero tu mensaje ♡

[8:25] **Tú:** [Imagen] y un mini yo para comenzar el día ♡

[16:59] **Maria. Valencia:**
> _Tú: a la proxima intentare que los foto video sean con luz jsjsj y bien se podria decir ya me siento mucho mejor en lo que energías respecta, la verdad_
jaksjsk el detalle es lo wue cuenta, tampoco para montar el trípode

[16:59] **Maria. Valencia:** era echándote broma jaksj

[16:59] **Maria. Valencia:**
> _Tú: el azul_
ah bueno q casualida

[17:00] **Maria. Valencia:**
> _Tú: ohh sisi entiendo eso una maña que tengo le tiro foto a algunos paisajes y eso y veo que tu tambien jsjsj_
es lo lindo de rotar en estos horarios, que aprovechas de ver el amanecer y atardecer

[17:01] **Maria. Valencia:**
> _Tú: tu como estas ya llegaste o algo? supongo que estas dormida o algo ya que no te caen los msg ojala descanses y estés bien espero tu mensaje ♡_
sii, habia caido rapido

[17:01] **Maria. Valencia:** ya ahorita me arreglo para ir al gym en un ratito

[17:01] **Maria. Valencia:** y a ti como te fue hoy?

[17:01] **Tú:** heyoo

[17:01] **Tú:**
> _Maria. Valencia: y a ti como te fue hoy?_
sigo aqui

[17:01] **Tú:** fui un poquito tarde hoy

[17:02] **Tú:**
> _Maria. Valencia: era echándote broma jaksj_
tranquila jsjsjsj

[17:02] **Tú:**
> _Maria. Valencia: ah bueno q casualida_
la verdad y tu con el pelo azul que por cierto hace cuanto te lo tintas?

[17:02] **Tú:**
> _Maria. Valencia: es lo lindo de rotar en estos horarios, que aprovechas de ver el amanecer y atardecer_
shi

[17:04] **Tú:** [Imagen]

[17:04] **Tú:** [Imagen]

[17:04] **Tú:** [Imagen] esas son algunas de las que he tomado tampoco voy a mandar toda la galería jsksksj

[17:04] **Tú:** [Imagen]

[17:04] **Tú:** [Imagen]

[17:04] **Tú:**
> _Maria. Valencia: ya ahorita me arreglo para ir al gym en un ratito_
anda esta bienn tranquila

[17:06] **Tú:** [Mensaje de video]

[17:45] **Maria. Valencia:**
> _Tú: Imagen: esas son algunas de las que he tomado tampoco voy a mandar toda la galería jsksksj_
[Sticker]

[17:46] **Maria. Valencia:**
> _Tú: Mensaje de video_
relajado todavia

[17:46] **Maria. Valencia:** [Sticker]

[17:46] **Maria. Valencia:**
> _Tú: la verdad y tu con el pelo azul que por cierto hace cuanto te lo tintas?_
ya tengo 3 años con el cabello de este color

[17:47] **Tú:**
> _Maria. Valencia: relajado todavia_
shi ya estoy terminando el último ejercicio para irme

[17:47] **Maria. Valencia:** lo he tenido largo, cortito

[17:47] **Tú:**
> _Maria. Valencia: ya tengo 3 años con el cabello de este color_
con todo el respeto que te mereces la verdad te queda fantástico y te ves bastante linda

[17:47] **Maria. Valencia:** tuve una pequeña epoca donde lo quise soltar pero no pude

[17:47] **Tú:**
> _Maria. Valencia: tuve una pequeña epoca donde lo quise soltar pero no pude_
ohh

[17:48] **Maria. Valencia:** [Imagen]

[17:48] **Maria. Valencia:** [Imagen]

[17:48] **Tú:** y que tinte usas o marca disculpa si es una pregunta rara

[17:48] **Tú:**
> _Maria. Valencia: Imagen_
que lindaaa, y buen accesorio ese de la cadera no se como se llama😅

[17:50] **Maria. Valencia:**
> _Tú: y que tinte usas o marca disculpa si es una pregunta rara_
uno de universe, el lycan

[17:50] **Maria. Valencia:** que es azul marino

[17:50] **Maria. Valencia:**
> _Tú: que lindaaa, y buen accesorio ese de la cadera no se como se llama😅_
jaja una cadena nomas

[17:51] **Tú:**
> _Maria. Valencia: uno de universe, el lycan_
esta bien bueno saberlo la verdad

[17:51] **Tú:** jsjsjs

[17:51] **Tú:**
> _Maria. Valencia: jaja una cadena nomas_
si bueno jsjsj y esa foto, fue en valencia o estabas de viaje en algun lado?

[17:54] **Maria. Valencia:**
> _Tú: si bueno jsjsj y esa foto, fue en valencia o estabas de viaje en algun lado?_
fue en tucacas, que habíamos alquilado lancha

[17:54] **Maria. Valencia:** a ti a donde prefieres ir? tipo la playa, cerro, piscina o de plano casita

[17:55] **Maria. Valencia:** o quizas eres mas de salir de noche?

[17:55] **Tú:**
> _Maria. Valencia: o quizas eres mas de salir de noche?_
nah

[17:55] **Tú:** esto no

[17:55] **Tú:** jsjsj

[17:55] **Tú:** soy mas hogareño que otra cosa

[17:55] **Tú:** peroooo

[17:55] **Tú:**
> _Maria. Valencia: a ti a donde prefieres ir? tipo la playa, cerro, piscina o de plano casita_
a lo que se de realmente

[17:55] **Tú:** no soy cerrado

[17:56] **Tú:** pero si es por preferencia piscina y playas, aunque la playa es medio miedo para mi porque no se flotar

[17:56] **Tú:** osea se nada pero me canso me ahogo porque no se estar como sin pisar sabes?

[17:56] **Tú:** y eso que soy de la guaira

[17:57] **Tú:** pero soy abierto a planes pues y mas si veo que sera divertido pero siempre con mi grupo de confianza de resto me la paso en mi casa

[17:58] **Tú:**
> _Maria. Valencia: Imagen_
😂

[17:58] **Tú:** que buen estado jsjsjs

[18:31] **Maria. Valencia:**
> _Tú: osea se nada pero me canso me ahogo porque no se estar como sin pisar sabes?_
bno yo tampoco me iría tan hondo para llegar a ese punto

[18:31] **Maria. Valencia:** JAJAJAJ

[18:32] **Maria. Valencia:** flotar vertical es arrecho

[18:32] **Maria. Valencia:**
> _Tú: y eso que soy de la guaira_
aunque sea fondo de bikini no significa que naces con las habilidades

[18:33] **Maria. Valencia:** ya quisiera jsksjs

[18:33] **Tú:**
> _Maria. Valencia: bno yo tampoco me iría tan hondo para llegar a ese punto_
entiendo jsjsj

[18:33] **Tú:**
> _Maria. Valencia: flotar vertical es arrecho_
imagino la verdad yo porque nunca pude y intento y nada

[18:35] **Tú:** yo ya voy camino a mi casa supongo y tu llegaste al gym cuidate mucho y que te vaya super bien con los ejercicios ♡

[20:41] **Maria. Valencia:** holi de nuevo

[20:41] **Maria. Valencia:** ya llegue a casa

[20:41] **Maria. Valencia:** q horrible luchar con tan poquito peso

[20:42] **Maria. Valencia:** [Sticker]

[20:42] **Maria. Valencia:** y tu en qué andas?

[21:03] **Tú:**
> _Maria. Valencia: q horrible luchar con tan poquito peso_
que te toco hoy marii?

[21:04] **Tú:**
> _Maria. Valencia: ya llegue a casa_
esho que buenoo

[21:04] **Tú:**
> _Maria. Valencia: y tu en qué andas?_
aquí en la pc jugando un ratito

[21:11] **Maria. Valencia:** hoy me tocó glúteos

[21:12] **Maria. Valencia:** y una ración de tembleque tambien jsksjs

[21:13] **Maria. Valencia:** ea y fobias? disgustos o miedos

[21:13] **Tú:**
> _Maria. Valencia: y una ración de tembleque tambien jsksjs_
eso va incluido todos lo dia

[21:13] **Maria. Valencia:** un odio irracional que le tengas a algo

[21:13] **Maria. Valencia:** a mi ahorita el mood me cambio ya que empezó a llover

[21:13] **Maria. Valencia:**
> _Tú: eso va incluido todos lo dia_
[Sticker]

[21:14] **Tú:**
> _Maria. Valencia: ea y fobias? disgustos o miedos_
verga fobias como tal a las arañas y un miedo grande a las oscuridad

[21:15] **Tú:**
> _Maria. Valencia: Sticker_
tu cada que sales del gym jsjsjsj

[21:18] **Tú:**
> _Maria. Valencia: a mi ahorita el mood me cambio ya que empezó a llover_
de buena o mala manera o un mood de solo descansar jsjsjs

[21:18] **Tú:**
> _Maria. Valencia: un odio irracional que le tengas a algo_
vrgg

[21:19] **Tú:** a las mentiras, odio mucho eso

[21:26] **Maria. Valencia:**
> _Tú: de buena o mala manera o un mood de solo descansar jsjsjs_
no sé, siempre se siente chimbo cada que llueve

[21:27] **Maria. Valencia:** no me gusta mucho asi

[21:27] **Maria. Valencia:** tipo lo bueno es que se pone fresco pero, como para dormir tampoco

[21:28] **Maria. Valencia:** [Sticker]

[21:28] **Tú:**
> _Maria. Valencia: no me gusta mucho asi_
yo quede con un trauma por la tragedia de vargas cada que llueve y lo que me contaron y eso quede como con miedo

[21:28] **Tú:**
> _Maria. Valencia: tipo lo bueno es que se pone fresco pero, como para dormir tampoco_
claro, claro

[21:29] **Tú:** y tu cuéntame?

[21:34] **Tú:**
> _Maria. Valencia: ea y fobias? disgustos o miedos_
sobre esto y eso

[22:36] **Maria. Valencia:**
> _Tú: yo quede con un trauma por la tragedia de vargas cada que llueve y lo que me contaron y eso quede como con miedo_
tambien que todo a nivel de desastre cae horrible

[22:36] **Maria. Valencia:** pero en general es chimbo pa

[22:36] **Maria. Valencia:**
> _Tú: y tu cuéntame?_
pos nada, ese es el odio irracional que tengo

[22:37] **Maria. Valencia:** miedo pos, quizá morir

[22:37] **Maria. Valencia:** y no me gusta que me subestimen xd

[22:37] **Maria. Valencia:** mas en el area que trabajo, que el ego se infla a lo flash

[22:38] **Maria. Valencia:** pa hombres y mujeres, no hay distinción ahi

[22:38] **Tú:** [Imagen] holaaa, justo te iba a volver a escribir pero vi que apareciste la verdad vi este trend y no tengo a quien mandárselo y pense en ti espero te guste♡

[22:39] **Tú:**
> _Maria. Valencia: pos nada, ese es el odio irracional que tengo_
ohh yaya entiendo jsjsj

[22:39] **Tú:**
> _Maria. Valencia: y no me gusta que me subestimen xd_
ok anotado lo tendré jsjsjs por ahora no lo he hecho ni pienso hacerlo y siempre te digo que puedes y te doy animos

[22:39] **Tú:**
> _Maria. Valencia: miedo pos, quizá morir_
ahora es que falta mucho tranquila

[22:40] **Tú:**
> _Maria. Valencia: mas en el area que trabajo, que el ego se infla a lo flash_
siii pasa bastante la verdad(no he estado en un ambiente asi pero si me han contando)

[22:40] **Tú:** yyy pregunta random de esta noche, 

¿cual es el mayor logro de has conseguido en tu vida y del que te sientes mas orgullosa?

[22:52] **Maria. Valencia:**
> _Tú: Imagen: holaaa, justo te iba a volver a escribir pero vi que apareciste la verdad vi este trend y no tengo a quien mandárselo y pense en ti espero te guste♡_
jaja hola de nuevo

[22:53] **Maria. Valencia:** buen momento para andar de atravesada

[22:53] **Maria. Valencia:**
> _Tú: ok anotado lo tendré jsjsjs por ahora no lo he hecho ni pienso hacerlo y siempre te digo que puedes y te doy animos_
[Sticker]

[22:54] **Maria. Valencia:** quiero imitar el corazon pero yo ni el chichón tengo

[22:54] **Maria. Valencia:** :(

[22:54] **Maria. Valencia:**
> _Tú: siii pasa bastante la verdad(no he estado en un ambiente asi pero si me han contando)_
si vale, si no tienes piel dura te hacen pollo guisado

[22:56] **Maria. Valencia:**
> _Tú: yyy pregunta random de esta noche, 

¿cual es el mayor logro de has conseguido en tu vida y del que te sientes mas orgullosa?_
le tengo cariño a la primera noche que me subieron a cocinera, porque pude con ese gentío

[22:56] **Maria. Valencia:** no me tenian fe jsksjaks y me felicitaron

[22:57] **Maria. Valencia:** es pequeño en realidad, porque quiero trabajar con comandas despues, pero son esas cositas que me alivia y recuerda que por ese sentimiento es que escogí quemarme en la cocina xdxd

[23:02] **Tú:**
> _Maria. Valencia: buen momento para andar de atravesada_
ay jsjsjsj

[23:03] **Tú:**
> _Maria. Valencia: quiero imitar el corazon pero yo ni el chichón tengo_
tranquila que yo estare aquí para cuando eso pase y puedas mandar esa foto confio en ti

[23:03] **Tú:**
> _Maria. Valencia: si vale, si no tienes piel dura te hacen pollo guisado_
sii

[23:04] **Tú:**
> _Maria. Valencia: no me tenian fe jsksjaks y me felicitaron_
esooooo que orgullo mari

[23:05] **Tú:**
> _Maria. Valencia: es pequeño en realidad, porque quiero trabajar con comandas despues, pero son esas cositas que me alivia y recuerda que por ese sentimiento es que escogí quemarme en la cocina xdxd_
tranquila no es pequeño es un logro y esos logros como tu dicen es lo que te recuerda y te da ese empujón de que vas muy bien

[23:06] **Tú:** y una pregunta esta vez reaccionaste la foto con el corazoncito azul tiene algun significado o razón mari?

[23:19] **Maria. Valencia:**
> _Tú: tranquila no es pequeño es un logro y esos logros como tu dicen es lo que te recuerda y te da ese empujón de que vas muy bien_
[Sticker]

[23:19] **Maria. Valencia:** y cual seria el tuyo?

[23:20] **Maria. Valencia:**
> _Tú: y una pregunta esta vez reaccionaste la foto con el corazoncito azul tiene algun significado o razón mari?_
como me dijiste que te gustaba el azul

[23:20] **Maria. Valencia:** por eso lo puse

[23:21] **Tú:**
> _Maria. Valencia: como me dijiste que te gustaba el azul_
...

[23:21] **Tú:** gracias

[23:21] **Tú:**
> _Maria. Valencia: y cual seria el tuyo?_
buenoo😅

[23:21] **Maria. Valencia:** [Sticker]

[23:22] **Tú:** dame un segundito

[23:22] **Tú:** que ando en partida y te lo cuento bien

[23:22] **Tú:** [Mensaje de video]

[23:22] **Maria. Valencia:** tranqui, exitazooo

[23:23] **Maria. Valencia:**
> _Tú: Mensaje de video_
jaksjs

[23:24] **Tú:** [Imagen] funciono jeje graciasss

[23:24] **Tú:** [Imagen] funciono jeje graciasss

[23:26] **Tú:** bueno siento que fue el dia que pude comprar mi aire condicionado yo solo y pude comprarle un iPhone a mi mama ya que ya su teléfono se estaba por dañar y siempre he querido darle todo ya que fue la mujer que me hizo ser quien soy a dia de hoy y la que me dio la vida

[23:28] **Tú:**
> _Tú: bueno siento que fue el dia que pude comprar mi aire condicionado yo solo y pude comprarle un iPhone a mi mama ya que ya su teléfono se estaba por dañar y siempre he querido darle todo ya que fue la mujer que me hizo ser quien soy a dia de hoy y la que me dio la vida_
[Mensaje de voz]

[23:29] **Tú:** y yo bueno puse el corazon naranja por obvias razones y tener ese juego de corazones te parece?

[23:36] **Maria. Valencia:**
> _Tú: bueno siento que fue el dia que pude comprar mi aire condicionado yo solo y pude comprarle un iPhone a mi mama ya que ya su teléfono se estaba por dañar y siempre he querido darle todo ya que fue la mujer que me hizo ser quien soy a dia de hoy y la que me dio la vida_
Awe que lindo gesto, asi vale mil veces mas

[23:36] **Maria. Valencia:** por todo el esfuerzo de reunir el dinero fua

[23:36] **Maria. Valencia:**
> _Tú: Mensaje de voz_
sii, aca hace demasiado calor

[23:37] **Maria. Valencia:** hasta de noche, ahorita que ando sin luz estoy rezando a que llegue

[23:37] **Maria. Valencia:** viendo que hago JAJAJ

[23:37] **Tú:**
> _Maria. Valencia: hasta de noche, ahorita que ando sin luz estoy rezando a que llegue_
queee

[23:37] **Tú:** no tiene luz??

[23:37] **Tú:** dios mio jsjsj

[23:37] **Maria. Valencia:**
> _Tú: Mensaje de voz_
uno es mas consiente de lo que se gasta cuando el golpe es de uno xd

[23:38] **Tú:**
> _Maria. Valencia: uno es mas consiente de lo que se gasta cuando el golpe es de uno xd_
LITERAAAL

[23:38] **Tú:** mis primas de alla en puerto cabello que mas es el tiempo sin luz que lo que tienen literal el ups es una obligación

[23:38] **Maria. Valencia:**
> _Tú: Mensaje de voz_
igual si ya pudiste con uno vas a poder con otro para ti

[23:38] **Tú:** por eso mi papa piensa en si ir hacia alla o no pero iremos pronto y estare por eso lados

[23:39] **Maria. Valencia:**
> _Tú: y yo bueno puse el corazon naranja por obvias razones y tener ese juego de corazones te parece?_
jaloo

[23:39] **Tú:**
> _Maria. Valencia: jaloo_
vaaaa

[23:39] **Maria. Valencia:**
> _Tú: mis primas de alla en puerto cabello que mas es el tiempo sin luz que lo que tienen literal el ups es una obligación_
a mi me falta es eso

[23:39] **Maria. Valencia:** tengo un powerbank por las idas a la playa

[23:39] **Maria. Valencia:** y con eso sobrevivo

[23:39] **Tú:**
> _Maria. Valencia: a mi me falta es eso_
y cuando cumples año se que en diciembre pero que dia?

[23:39] **Maria. Valencia:** la switch tmb sirve de cargador

[23:39] **Tú:**
> _Maria. Valencia: tengo un powerbank por las idas a la playa_
vrg imagínate almenos que chimbo que no tengas el ups

[23:40] **Tú:**
> _Maria. Valencia: la switch tmb sirve de cargador_
enserió? no sabia

[23:40] **Maria. Valencia:**
> _Tú: y cuando cumples año se que en diciembre pero que dia?_
cumplo el 14

[23:40] **Maria. Valencia:** me cae trabajando :(

[23:41] **Maria. Valencia:** y el tuyo que esta por venir supongo

[23:41] **Tú:**
> _Maria. Valencia: me cae trabajando :(_
ayy imagínate

[23:41] **Tú:**
> _Maria. Valencia: y el tuyo que esta por venir supongo_
yo? yo ya cumpli jsjsjs

[23:41] **Maria. Valencia:** :0

[23:41] **Maria. Valencia:** cuando?

[23:41] **Maria. Valencia:** como dijiste que ibas para 20

[23:41] **Tú:** pero es que si empezando el año por allí

[23:41] **Maria. Valencia:** ahhh

[23:41] **Tú:**
> _Maria. Valencia: como dijiste que ibas para 20_
17 de abril

[23:41] **Tú:** 😅😅😅😅😅

[23:41] **Maria. Valencia:** ow vava

[23:42] **Tú:**
> _Maria. Valencia: cumplo el 14_
14 y cumples 24

[23:42] **Tú:** casualidades jsjsjs

[23:42] **Maria. Valencia:** ah bueno si, de verdad

[23:42] **Tú:** y tu gym tiene para pagar el diario?

[23:42] **Maria. Valencia:** no me habia dado cuenta jsksj

[23:43] **Tú:** o solo mensual

[23:43] **Maria. Valencia:**
> _Tú: y tu gym tiene para pagar el diario?_
si, no sé cuanto es pero si está

[23:43] **Maria. Valencia:** tiene mensual, semanal

[23:43] **Maria. Valencia:** y diario

[23:43] **Tú:**
> _Maria. Valencia: si, no sé cuanto es pero si está_
va esta bien es que cuando me toque ir para allá que en un tiempo

[23:43] **Tú:** no quiero faltar al gym

[23:44] **Tú:** y como no conocía ninguno cerca no se si todo sale bien podria estar entrenando los días que este por alla contigo

[23:44] **Tú:** si gustas claro esta ya que lo menos que busco es incomodarte

[23:45] **Tú:** pd: el sábado que viene quiero invitarte a algo en caracas te aviso por que como me dijiste que libras lo findes tengo un plan

[23:45] **Tú:** mas no se si puedas o estés disponible

[23:45] **Maria. Valencia:**
> _Tú: si gustas claro esta ya que lo menos que busco es incomodarte_
tranquii, mientras esté libre si puede ser

[23:45] **Maria. Valencia:**
> _Tú: mas no se si puedas o estés disponible_
yo subo el viernes justamente jskdj

[23:46] **Tú:**
> _Maria. Valencia: yo subo el viernes justamente jskdj_
mira tu mas perfecto no puede ser jsjsjsjs

[23:46] **Tú:** y eso que subes?

[23:46] **Maria. Valencia:** si es tarde mejor porque si iba con la intencion de subir con mi prima al Avila

[23:46] **Maria. Valencia:** [Sticker]

[23:46] **Maria. Valencia:** ya has subido??

[23:46] **Tú:**
> _Maria. Valencia: si es tarde mejor porque si iba con la intencion de subir con mi prima al Avila_
tranquila yo me adapto a tu horario

[23:46] **Tú:**
> _Maria. Valencia: ya has subido??_
nooop

[23:46] **Maria. Valencia:** nunca has subido un cerro?

[23:47] **Maria. Valencia:** no te invito porque me conozco y soy medio inmamable

[23:47] **Tú:**
> _Maria. Valencia: nunca has subido un cerro?_
si pero no he subido el avila ni tampoco galipan( es un plan que hace mucha gente aja )

[23:47] **Maria. Valencia:** [Sticker]

[23:47] **Tú:**
> _Maria. Valencia: no te invito porque me conozco y soy medio inmamable_
tranquila que paciencia es lo que me sobra y mas si se trata de ti

[23:47] **Tú:** y algun dia te voy a conocer en persona

[23:47] **Tú:** pero como tu veas

[23:47] **Tú:** [Sticker]

[23:48] **Maria. Valencia:**
> _Tú: si pero no he subido el avila ni tampoco galipan( es un plan que hace mucha gente aja )_
pero cual??

[23:48] **Maria. Valencia:** yo sufro pero siempre termino disfrutando la vista

[23:48] **Maria. Valencia:** solo he podido con dos

[23:48] **Tú:**
> _Maria. Valencia: pero cual??_
cerros ps osea un cerro hacia unas casas jsjsjs no una montaña como tal

[23:48] **Maria. Valencia:**
> _Tú: y algun dia te voy a conocer en persona_
[Sticker]

[23:49] **Tú:** [Mensaje de voz]

[23:49] **Maria. Valencia:**
> _Tú: cerros ps osea un cerro hacia unas casas jsjsjs no una montaña como tal_
te pierdes de la experiencia 1000 maneras de morir

[23:49] **Maria. Valencia:**
> _Tú: Mensaje de voz_
JAJAJA

[23:49] **Maria. Valencia:** yo los conozco asi

[23:49] **Tú:**
> _Maria. Valencia: yo los conozco asi_
ay mi ma.

[23:49] **Tú:** jsjjs

[23:50] **Tú:** [Mensaje de voz]

[23:50] **Tú:**
> _Maria. Valencia: te pierdes de la experiencia 1000 maneras de morir_
JAJAJAJAJAJ

[23:51] **Tú:** ya veré si algun dia vale la pena o no jsjsjs

[23:51] **Maria. Valencia:**
> _Tú: Mensaje de voz_
pos si, ya en la tarde quiero suponer

[23:51] **Maria. Valencia:** tampoco creo que tarde mucho, eso es en la mañana

[23:51] **Maria. Valencia:**
> _Tú: ya veré si algun dia vale la pena o no jsjsjs_
que sii

[23:51] **Maria. Valencia:** mira

[23:52] **Tú:**
> _Maria. Valencia: que sii_
buenoo si tu lo dices te creo

[23:52] **Maria. Valencia:** [Imagen]

[23:52] **Maria. Valencia:** [Mensaje de unknown]

[23:52] **Tú:**
> _Maria. Valencia: tampoco creo que tarde mucho, eso es en la mañana_
[Mensaje de voz]

[23:52] **Tú:**
> _Maria. Valencia: Imagen_
que bellooo

[23:52] **Tú:** me convenciste si vale la pena

[23:55] **Maria. Valencia:** [Imagen]

[23:55] **Maria. Valencia:** [Imagen]

[23:55] **Tú:**
> _Maria. Valencia: Imagen_
dios mio.

[23:55] **Tú:** foton

[23:56] **Tú:**
> _Maria. Valencia: Imagen_
[Mensaje de voz]

[23:56] **Maria. Valencia:**
> _Tú: Mensaje de voz_
yo al final me puedo pedir un taxi hacia coche, no se si te sirva de referencia

[23:56] **Maria. Valencia:**
> _Tú: me convenciste si vale la pena_
de lo juroo

[23:57] **Maria. Valencia:**
> _Tú: Mensaje de voz_
ay a mi me encantan

[23:57] **Maria. Valencia:** ese es el chiste ps, sufrir y disfrutar

[23:57] **Maria. Valencia:**
> _Maria. Valencia: Imagen_
porque llegar aqui fue horrible

[23:57] **Maria. Valencia:** ni siquiera era la cascada que queríamos ver

[23:58] **Tú:**
> _Maria. Valencia: yo al final me puedo pedir un taxi hacia coche, no se si te sirva de referencia_
[Mensaje de voz]

[23:58] **Tú:**
> _Maria. Valencia: ni siquiera era la cascada que queríamos ver_
naguaraa

[23:58] **Tú:** imagínate

---

## 7 de noviembre de 2026

[0:00] **Maria. Valencia:**
> _Tú: Mensaje de voz_
fua duraste demasiado

[0:00] **Tú:**
> _Maria. Valencia: ese es el chiste ps, sufrir y disfrutar_
una ola de emociones como quien dice

[0:00] **Maria. Valencia:** nosotras comimos y nos vinieron a buscar

[0:00] **Maria. Valencia:** porque si, yo tenia que dormir para irme

[0:00] **Maria. Valencia:** mi prima me tuvo piedad

[0:01] **Maria. Valencia:** y es que eso se llenó demasiado

[0:01] **Tú:**
> _Maria. Valencia: fua duraste demasiado_
te lo juro yo a las 2 ya estaba todo estresado jsjjs

[0:01] **Tú:**
> _Maria. Valencia: y es que eso se llenó demasiado_
horrible

[0:02] **Tú:**
> _Maria. Valencia: nosotras comimos y nos vinieron a buscar_
[Mensaje de voz]

[0:02] **Tú:**
> _Maria. Valencia: mi prima me tuvo piedad_
imagino jsjsjs

[0:03] **Tú:** [Mensaje de voz]

[0:04] **Tú:** disculpa los audios largos, te llega a incomodar o molestar eso?

[0:05] **Maria. Valencia:**
> _Tú: Mensaje de voz_
estaban demasiado caros

[0:05] **Maria. Valencia:** yo lo sé JAJAJA

[0:05] **Maria. Valencia:** pero nos quedamos ahi por cansancio

[0:05] **Maria. Valencia:** ni siquiera estaban buenos

[0:05] **Tú:**
> _Maria. Valencia: ni siquiera estaban buenos_
los mio si estaban sabrosos jsjjss

[0:05] **Maria. Valencia:** [Sticker]

[0:05] **Tú:** almenos

[0:06] **Tú:**
> _Maria. Valencia: estaban demasiado caros_
cosas de las mercedes, es como una zona sifrina en ccs

[0:06] **Maria. Valencia:**
> _Tú: Mensaje de voz_
sosten mi bolsa, tal cual

[0:06] **Maria. Valencia:** JAJAJA

[0:08] **Maria. Valencia:**
> _Tú: Mensaje de voz_
bno hiciste full jornada con el traje jsksjs

[0:08] **Tú:**
> _Maria. Valencia: bno hiciste full jornada con el traje jsksjs_
me falto ser peluche de bus jsjsjsj

[0:09] **Maria. Valencia:** ella me habia invitado porque iba con sus amigas, que se habian comprado su traje en grupito y tal

[0:09] **Tú:** yo de nightwing y mi mejor amigo de ben 10 literal era un super meme porque no íbamos para nada combinados

[0:09] **Tú:**
> _Maria. Valencia: ella me habia invitado porque iba con sus amigas, que se habian comprado su traje en grupito y tal_
si eso vi en esa foto

[0:09] **Maria. Valencia:** y bno para aprovechar de disfrazarme

[0:09] **Maria. Valencia:** yo aca no tengo amigas asi para rumbear ni nada

[0:10] **Maria. Valencia:** mas bien es la segunda vez que salgo a una discoteca

[0:10] **Tú:**
> _Maria. Valencia: mas bien es la segunda vez que salgo a una discoteca_
entiendo, entiendo

[0:10] **Tú:** me vas ganando por 1 jsjsjs

[0:10] **Tú:**
> _Maria. Valencia: yo aca no tengo amigas asi para rumbear ni nada_
yo porque no se siempre al rato me aburro y como no tomo no fumo no consumo nada asi aja

[0:10] **Tú:** yo pido mi coca zero aparte y ya

[0:11] **Maria. Valencia:**
> _Tú: me vas ganando por 1 jsjsjs_
vamos contando veces ahora jsksj

[0:11] **Tú:** es muy jodido para que tome algo ps

[0:11] **Maria. Valencia:**
> _Tú: yo pido mi coca zero aparte y ya_
yo estoy todavia intentando dejar los refrescos pero

[0:11] **Tú:**
> _Maria. Valencia: vamos contando veces ahora jsksj_
despues contaremos otras cosas jsjsjs

[0:11] **Maria. Valencia:** todo lo light sabe a remedio

[0:11] **Maria. Valencia:** [Sticker]

[0:11] **Tú:**
> _Maria. Valencia: todo lo light sabe a remedio_
mas o menos realmente

[0:11] **Tú:** yo porque deje los azúcares a la fuerza

[0:12] **Tú:** pesaba 120kg

[0:12] **Tú:** y fue cuando dije

[0:12] **Tú:** [Sticker]

[0:12] **Maria. Valencia:** fua

[0:12] **Maria. Valencia:** entraste chamito al gym entonces

[0:12] **Tú:** me voy a morir para la verga

[0:12] **Tú:**
> _Maria. Valencia: entraste chamito al gym entonces_
noo vale

[0:12] **Tú:** llevo 1 mes y medio

[0:12] **Tú:** solo que hacía deporte y eso me hizo rebajar

[0:13] **Tú:** el basket y los entrenamientos fue lo que me hizo super bajar la panza y estar en mejores condiciones

[0:13] **Maria. Valencia:**
> _Tú: el basket y los entrenamientos fue lo que me hizo super bajar la panza y estar en mejores condiciones_
berro si, te dió el super empujón

[0:13] **Tú:** y ya que baje de peso "entre comillas" peso 93kg estoy intentando verme mejor

[0:13] **Maria. Valencia:** buenos hábitos tambien

[0:13] **Tú:**
> _Maria. Valencia: berro si, te dió el super empujón_
seeh eso es algo que te contaré en mas confianza

[0:14] **Tú:** fue etapas depresión y muchas cosas

[0:14] **Tú:** y me salvo eso

[0:14] **Tú:** el deporte

[0:14] **Tú:** encontrarme con mi familia

[0:14] **Tú:** ser mejor hijo mejor hermano, y mas importante mejor persona

[0:15] **Maria. Valencia:**
> _Tú: fue etapas depresión y muchas cosas_
distraerse de esas fases es arrecho, mas bien mucho mérito ah

[0:15] **Tú:** entonces siempre intento estar ocupado por eso juego basket voy al gym trabajo y estudio, y si dios quiere y me sale bien trabaje doble, de secretario en una escuela que conozco y en mi casa asi gano mas dinero y me administro mejor

[0:15] **Tú:** mi meta es a los 23 tener un carrito

[0:15] **Tú:** no me gustan las motos

[0:15] **Tú:**
> _Maria. Valencia: distraerse de esas fases es arrecho, mas bien mucho mérito ah_
[Sticker]

[0:15] **Tú:** muchas gracias mari

[0:16] **Maria. Valencia:**
> _Tú: entonces siempre intento estar ocupado por eso juego basket voy al gym trabajo y estudio, y si dios quiere y me sale bien trabaje doble, de secretario en una escuela que conozco y en mi casa asi gano mas dinero y me administro mejor_
la ambición es lo que mueve todo

[0:16] **Maria. Valencia:** [Sticker]

[0:16] **Maria. Valencia:** un poco de envidia jskdjs

[0:17] **Maria. Valencia:** mientras sigas unido a tu familia y a los que quieres

[0:17] **Maria. Valencia:** seguro consigues eso y mas con esas ganss

[0:17] **Tú:**
> _Maria. Valencia: un poco de envidia jskdjs_
tranquila que asi como estoy intento que los que me rodean lo logren

[0:17] **Tú:** me hace feliz hacer a los demás felices

[0:17] **Tú:** y créeme que tu no serás la excepción

[0:18] **Tú:**
> _Maria. Valencia: seguro consigues eso y mas con esas ganss_
gachass

[0:19] **Tú:** y una consulta, te puedo seguir en tiktok?

[0:25] **Maria. Valencia:** si vale, tambien te doy el seguido

[0:25] **Maria. Valencia:** [Sticker]

[0:26] **Tú:**
> _Maria. Valencia: si vale, tambien te doy el seguido_
vava jsjsj

[0:27] **Maria. Valencia:** por ciertoo

[0:27] **Maria. Valencia:** sigues jugando?

[0:27] **Tú:**
> _Maria. Valencia: sigues jugando?_
noop

[0:28] **Tú:** gane esa partida y me concentre aca en hablar contigo

[0:28] **Maria. Valencia:** ya listo para dormir tons

[0:28] **Maria. Valencia:**
> _Tú: gane esa partida y me concentre aca en hablar contigo_
ay

[0:28] **Maria. Valencia:** [Sticker]

[0:28] **Tú:**
> _Maria. Valencia: ya listo para dormir tons_
sii pensaba en eso mas que todo de tu parte

[0:28] **Tú:**
> _Maria. Valencia: ya listo para dormir tons_
buenoo a momir?

[0:28] **Tú:** miraaa

[0:28] **Maria. Valencia:** miro

[0:28] **Tú:** justo cree un sticker pensando en eso

[0:28] **Tú:** [Sticker]

[0:29] **Tú:** 🤣🤣🤣

[0:29] **Maria. Valencia:** deberia intentar dormir porque mañana si tengo que salir temprano

[0:29] **Maria. Valencia:**
> _Tú: Sticker_
AWE

[0:29] **Maria. Valencia:** [Sticker]

[0:29] **Tú:**
> _Maria. Valencia: Sticker_
JAJAJAJAJ

[0:29] **Maria. Valencia:** esta cuchi

[0:29] **Tú:** [Mensaje de voz]

[0:29] **Tú:**
> _Maria. Valencia: esta cuchi_
shii

[0:30] **Maria. Valencia:**
> _Tú: Mensaje de voz_
bno un tipo preparado vale por dos

[0:30] **Maria. Valencia:** hsksjaj

[0:30] **Tú:**
> _Maria. Valencia: bno un tipo preparado vale por dos_
obviooo jeje

[0:30] **Maria. Valencia:** pero si, positivo para procedimientos

[0:30] **Tú:** buenoo

[0:30] **Maria. Valencia:** a mimir

[0:30] **Maria. Valencia:** que descanses y duermas super bn

[0:31] **Maria. Valencia:** [Sticker]

[0:31] **Tú:** [Mensaje de video]

[0:31] **Tú:** mi pelo no es asi de normal lo prometo jsjsj

[0:33] **Maria. Valencia:**
> _Tú: Mensaje de video_
JAJAJA fua

[0:33] **Maria. Valencia:** dale ya tienes permiso de apagarla

[0:33] **Maria. Valencia:** Esito dio

[0:33] **Tú:**
> _Maria. Valencia: dale ya tienes permiso de apagarla_
esta bien mami🧡

[0:33] **Maria. Valencia:** pff

[0:33] **Maria. Valencia:** jsksjka vaya a dormir

[0:33] **Maria. Valencia:** sueña lindo

[0:33] **Maria. Valencia:** chao

[0:34] **Tú:**
> _Maria. Valencia: sueña lindo_
espero soñar contigo entonces jsjsjs

[0:34] **Tú:**
> _Maria. Valencia: chao_
chauuu

[0:34] **Tú:**
> _Maria. Valencia: Esito dio_
esto no lo entendi muy bien pero me lo explicas mñn jsjs

[11:57] **Tú:** [Mensaje de video]

[12:23] **Maria. Valencia:** yava que apenitas y me llega señal

[12:23] **Maria. Valencia:** buenas buenass

[12:24] **Maria. Valencia:**
> _Tú: esto no lo entendi muy bien pero me lo explicas mñn jsjs_
como decir pobrecito dios

[12:24] **Maria. Valencia:** [Sticker]

[12:25] **Tú:**
> _Maria. Valencia: como decir pobrecito dios_
ahh mucho mejor y asi me gusto mas el msg

[12:25] **Tú:**
> _Maria. Valencia: yava que apenitas y me llega señal_
dale tranquila no te preocupes

[12:25] **Tú:** aunquee, como amaneces?

[12:25] **Maria. Valencia:**
> _Tú: Mensaje de video_
naii

[12:25] **Maria. Valencia:** mi amiga queria ir a una zona de valencia

[12:25] **Maria. Valencia:** nos asustamos y nos vinimos al sambil

[12:26] **Tú:**
> _Maria. Valencia: mi amiga queria ir a una zona de valencia_
ayy

[12:26] **Tú:** jsjsjsjs

[12:26] **Tú:**
> _Maria. Valencia: nos asustamos y nos vinimos al sambil_
ahh esta bien que la pases super bien con tu amiga alli en el sambil

[12:27] **Tú:** y eres una exploradora, mari la exploradora

[12:35] **Maria. Valencia:** _Esperando el mensaje… Esto puede demorar un poco._

[12:42] **Tú:**
> _Maria. Valencia: Imagen_
full combinada jsjsjs

[12:43] **Tú:** y estas muy lindaa, marii

[14:21] **Maria. Valencia:** si jsjdjs

[14:22] **Maria. Valencia:** [Imagen]

[14:22] **Maria. Valencia:** [Imagen]

[14:22] **Tú:**
> _Maria. Valencia: Imagen_
[Sticker]

[14:22] **Tú:** estas muy lindaaaaaa

[14:22] **Tú:** graciass por la fotoo

[14:22] **Maria. Valencia:** [Imagen]

[14:22] **Maria. Valencia:** [Imagen]

[14:23] **Maria. Valencia:** estamos viendo que comer porque nos quedamos varadas

[14:23] **Tú:**
> _Maria. Valencia: Imagen_
woow es el sambil de allá no?

[14:23] **Maria. Valencia:** allá esta lloviendo??

[14:23] **Maria. Valencia:** [Sticker]

[14:23] **Tú:**
> _Maria. Valencia: allá esta lloviendo??_
suuper

[14:23] **Tú:** [Imagen] yo ando asi por el frío

[14:23] **Tú:** [Imagen] yo ando asi por el frío

[14:24] **Maria. Valencia:** jajs la unica vez que hace frio

[14:24] **Tú:**
> _Maria. Valencia: allá esta lloviendo??_
y tronando super feo aparté

[14:24] **Tú:** alla me imagino que igual supongo

[14:24] **Tú:**
> _Maria. Valencia: jajs la unica vez que hace frio_
si eso mas estar en el cuarto con aire

[14:25] **Tú:** [Imagen] asi esta el tiempo mas o menos

[14:25] **Tú:** [Imagen] asi esta el tiempo mas o menos

[14:26] **Tú:**
> _Maria. Valencia: estamos viendo que comer porque nos quedamos varadas_
ojala consiga algo rico para comer provechito adelantado por si algo

[14:27] **Maria. Valencia:** [Video]

[14:28] **Tú:**
> _Maria. Valencia: Video_
ay

[14:28] **Tú:** [Sticker]

[14:28] **Tú:** el super palo de agua pues

[14:28] **Maria. Valencia:** [Video]

[14:28] **Tú:**
> _Maria. Valencia: Imagen_
[Sticker]
